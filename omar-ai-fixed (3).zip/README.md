# Omar AI – Production Android App

Package: `com.omar.ai`  
Firebase Project: `omar-ai-67541`

## Key changes in this build

1. **Gemini via Firebase AI Logic** (no API key in APK)
   - Uses `Firebase.ai(backend = GenerativeBackend.googleAI())`
   - Model: `gemini-2.0-flash`
   - Enable in Firebase Console → Build → AI Logic / Gemini

2. **Google Sign-In**
   - Web client ID fixed to the one from `google-services.json`
   - Requires Google provider enabled + correct SHA-1/SHA-256 fingerprints in Firebase

3. **Email / Password** already implemented with Firebase Auth + local fallback

4. **google-services.json** placed under `app/`

## Manual steps you must do in Firebase / Google Cloud

1. Firebase Console → Authentication → Sign-in method  
   - Enable **Google**  
   - Enable **Email/Password**

2. Firebase Console → Project settings → Your apps → Android (`com.omar.ai`)  
   - Confirm SHA-1 fingerprint matches your keystore  
   - Current registered hash (from google-services): `1da2148846c8ea154e3a89c787d82f0a5413c388`  
   - Add debug & release SHA-1 / SHA-256 if different

3. Firebase Console → AI Logic (or Vertex AI / Gemini)  
   - Enable Gemini Developer API for this project

4. (Strongly recommended) App Check  
   - Register the app and enable enforcement for AI Logic

5. OAuth consent screen (Google Cloud Console) should include the package and the web client ID used for Sign-In.

## Build

```bash
# Open in Android Studio
# Sync Gradle
# Run on device/emulator with Google Play services
```

No `.env` with GEMINI_API_KEY is required anymore.

## Smart Sync (Firestore)

Enabled by default for signed-in Google / Email users (not guests).

### Structure
```
users/{uid}/conversations/{conversationId}
users/{uid}/conversations/{conversationId}/messages/{messageId}
users/{uid}/memories/{memoryId}
users/{uid}/todos/{todoId}
```

### Firebase Console steps
1. Build → Firestore Database → Create database (production or test mode, then lock rules)
2. Use these security rules:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

3. Settings in the app: toggle **المزامنة الذكية / Smart Sync**

### Behavior
- On login → pull cloud data into local Room
- After each chat / memory change → debounced push to cloud
- Offline-first: local Room always works; sync when online

## Phone Authentication

1. Firebase Console → Authentication → Sign-in method → enable **Phone**
2. Add your app's SHA-1 / SHA-256 (required for SafetyNet / Play Integrity)
3. For testing: Authentication → Phone → Phone numbers for testing
4. User enters E.164 number (e.g. +201234567890) → receives SMS → enters code

Note: Phone auth does not work on emulators without test numbers configured.

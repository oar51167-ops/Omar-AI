package com.omar.ai.data.ai

import com.omar.ai.data.local.ChatMessageEntity
import com.omar.ai.data.local.MemoryEntity
import com.omar.ai.data.model.ActionCall
import com.omar.ai.data.model.AssistantMode

data class WebSource(
    val title: String,
    val url: String
)

data class AIResponse(
    val text: String,
    val actionCall: ActionCall? = null,
    val suggestions: List<String> = emptyList(),
    val generatedImageBase64: String? = null,
    val generatedVideoUri: String? = null,
    val webSources: List<WebSource> = emptyList(),
    val isError: Boolean = false,
    val errorMessage: String? = null
)

interface AIProvider {
    val providerName: String

    suspend fun generateResponse(
        conversationHistory: List<ChatMessageEntity>,
        userMessage: String,
        userImageBase64: String?,
        mode: AssistantMode,
        longTermMemories: List<MemoryEntity>
    ): AIResponse

    suspend fun generateTitle(firstUserMessage: String): String

    suspend fun generateImage(prompt: String): Result<String>
}

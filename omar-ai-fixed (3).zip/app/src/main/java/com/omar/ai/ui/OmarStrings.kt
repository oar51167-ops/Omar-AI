package com.omar.ai.ui

object OmarStrings {
    // App Branding
    fun appName(isAr: Boolean) = "Omar AI"
    fun greetingHeader(isAr: Boolean) = if (isAr) "كيف يمكنني مساعدتك؟" else "How can I help you today?"
    fun welcomeNewChat(isAr: Boolean) = if (isAr) "مرحبًا! أنا Omar AI 🤖\nماذا تريد أن نفعل اليوم؟" else "Hello! I am Omar AI 🤖\nWhat would you like to explore today?"
    fun newChat(isAr: Boolean) = if (isAr) "محادثة جديدة" else "New Chat"
    fun temporaryChat(isAr: Boolean) = if (isAr) "محادثة مؤقتة" else "Temporary Chat"
    fun tempChatNotice(isAr: Boolean) = if (isAr) "هذه المحادثة مؤقتة ولن تُحفظ في السجل أو الذاكرة." else "This conversation is temporary and won't be saved."

    // Onboarding
    fun onboardingTitle(isAr: Boolean) = if (isAr) "مرحبًا بك في Omar AI" else "Welcome to Omar AI"
    fun onboardingDesc(isAr: Boolean) = if (isAr) "مساعدك الشخصي الفائق للذكاء الاصطناعي، الدراسة، البرمجة، والصوت والتحكم." else "Your advanced AI assistant for intelligence, study, coding, voice, and phone actions."
    fun continueWithGoogle(isAr: Boolean) = if (isAr) "المتابعة باستخدام Google" else "Continue with Google"
    fun continueAsGuest(isAr: Boolean) = if (isAr) "المتابعة بدون حساب" else "Continue as Guest"
    fun guestModeNotice(isAr: Boolean) = if (isAr) "وضع الضيف: يتم حفظ جميع بياناتك ومحادثاتك محليًا بأمان على هاتفك." else "Guest Mode: All data and chats are stored securely on your device."

    // Modes
    fun modeGeneral(isAr: Boolean) = if (isAr) "عام" else "General"
    fun modeStudy(isAr: Boolean) = if (isAr) "دراسة" else "Study"
    fun modeCoding(isAr: Boolean) = if (isAr) "برمجة" else "Coding"
    fun modeWork(isAr: Boolean) = if (isAr) "عمل" else "Work"

    // Composer
    fun typeMessagePlaceholder(isAr: Boolean) = if (isAr) "اكتب رسالة إلى Omar AI..." else "Message Omar AI..."
    fun send(isAr: Boolean) = if (isAr) "إرسال" else "Send"
    fun voiceChat(isAr: Boolean) = if (isAr) "محادثة صوتية" else "Voice Chat"
    fun attachMedia(isAr: Boolean) = if (isAr) "إرفاق وسائط" else "Attach Media"
    fun camera(isAr: Boolean) = if (isAr) "كاميرا" else "Camera"
    fun gallery(isAr: Boolean) = if (isAr) "صور" else "Photos"
    fun document(isAr: Boolean) = if (isAr) "مستندات" else "Documents"

    // Voice States
    fun listening(isAr: Boolean) = if (isAr) "جارٍ الاستماع إليك..." else "Listening to you..."
    fun thinking(isAr: Boolean) = if (isAr) "Omar AI يفكر..." else "Omar AI is thinking..."
    fun speaking(isAr: Boolean) = if (isAr) "Omar AI يتحدث..." else "Omar AI is speaking..."
    fun tapToSpeak(isAr: Boolean) = if (isAr) "انقر للتحدث" else "Tap to speak"
    fun tapToStop(isAr: Boolean) = if (isAr) "انقر للإيقاف" else "Tap to stop"

    // Actions & Tools
    fun retry(isAr: Boolean) = if (isAr) "إعادة المحاولة" else "Retry"
    fun regenerate(isAr: Boolean) = if (isAr) "إعادة التوليد" else "Regenerate"
    fun edit(isAr: Boolean) = if (isAr) "تعديل" else "Edit"
    fun copy(isAr: Boolean) = if (isAr) "نسخ" else "Copy"
    fun copied(isAr: Boolean) = if (isAr) "تم النسخ للحافظة" else "Copied to clipboard"
    fun share(isAr: Boolean) = if (isAr) "مشاركة" else "Share"
    fun delete(isAr: Boolean) = if (isAr) "حذف" else "Delete"
    fun pin(isAr: Boolean) = if (isAr) "تثبيت" else "Pin"
    fun unpin(isAr: Boolean) = if (isAr) "إلغاء التثبيت" else "Unpin"
    fun archive(isAr: Boolean) = if (isAr) "أرشفة" else "Archive"
    fun rename(isAr: Boolean) = if (isAr) "تغيير الاسم" else "Rename"

    // Contact confirmation
    fun callContactConfirm(isAr: Boolean, name: String) = if (isAr) "هل تريد الاتصال بـ $name؟" else "Do you want to call $name?"
    fun call(isAr: Boolean) = if (isAr) "اتصال" else "Call"
    fun cancel(isAr: Boolean) = if (isAr) "إلغاء" else "Cancel"

    // Drawer & History
    fun chatHistory(isAr: Boolean) = if (isAr) "سجل المحادثات" else "Chat History"
    fun searchChats(isAr: Boolean) = if (isAr) "بحث في المحادثات..." else "Search chats..."
    fun pinnedChats(isAr: Boolean) = if (isAr) "المحادثات المثبتة" else "Pinned Chats"
    fun recentChats(isAr: Boolean) = if (isAr) "المحادثات الأخيرة" else "Recent Chats"
    fun clearAll(isAr: Boolean) = if (isAr) "مسح الكل" else "Clear All"

    // Memory & To-Do & Reminders
    fun memory(isAr: Boolean) = if (isAr) "ذاكرة Omar AI" else "Omar AI Memory"
    fun memoryDesc(isAr: Boolean) = if (isAr) "المعلومات والسياق طويل المدى المحفوظ لتخصيص إجاباتك" else "Long-term context saved to personalize your answers"
    fun addMemory(isAr: Boolean) = if (isAr) "إضافة معلومة للذاكرة" else "Add Memory"
    fun memoryKey(isAr: Boolean) = if (isAr) "المفتاح (مثل: اسمي، وظيفتي)" else "Key (e.g. My name, My profession)"
    fun memoryValue(isAr: Boolean) = if (isAr) "القيمة أو التفاصيل" else "Value or details"
    fun todos(isAr: Boolean) = if (isAr) "قائمة المهام" else "To-Do List"
    fun addTodo(isAr: Boolean) = if (isAr) "إضافة مهمة جديدة" else "Add New Task"
    fun reminders(isAr: Boolean) = if (isAr) "التذكيرات النشطة" else "Active Reminders"

    // Settings
    fun settings(isAr: Boolean) = if (isAr) "الإعدادات" else "Settings"
    fun profile(isAr: Boolean) = if (isAr) "الملف الشخصي" else "Profile"
    fun language(isAr: Boolean) = if (isAr) "اللغة" else "Language"
    fun theme(isAr: Boolean) = if (isAr) "المظهر" else "Theme"
    fun themeDark(isAr: Boolean) = if (isAr) "الوضع الداكن" else "Dark Mode"
    fun themeLight(isAr: Boolean) = if (isAr) "الوضع الفاتح" else "Light Mode"
    fun themeSystem(isAr: Boolean) = if (isAr) "تلقائي (حسب النظام)" else "System Default"
    fun autoSpeak(isAr: Boolean) = if (isAr) "نطق الإجابات تلقائيًا" else "Auto Speak Responses"
    fun voiceSpeed(isAr: Boolean) = if (isAr) "سرعة الصوت" else "Voice Speed"
    fun defaultAssistant(isAr: Boolean) = if (isAr) "تعيين كمساعد رقمي افتراضي" else "Set as Default Assistant"
    fun defaultAssistantDesc(isAr: Boolean) = if (isAr) "اختر Omar AI كمساعدك الرقمي في إعدادات Android الرسمية." else "Choose Omar AI as your default digital assistant in Android settings."
    fun privacyTerms(isAr: Boolean) = if (isAr) "الخصوصية والشروط" else "Privacy & Terms"
    fun deleteAccount(isAr: Boolean) = if (isAr) "حذف الحساب والبيانات" else "Delete Account & Data"
    fun signOut(isAr: Boolean) = if (isAr) "تسجيل الخروج" else "Sign Out"
    fun guestBadge(isAr: Boolean) = if (isAr) "حساب ضيف محلي" else "Local Guest Account"
    fun syncWithGoogle(isAr: Boolean) = if (isAr) "مزامنة مع حساب Google" else "Sync with Google Account"
    fun syncSuccess(isAr: Boolean) = if (isAr) "تمت المزامنة بنجاح" else "Synced successfully"
}

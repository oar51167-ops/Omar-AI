package com.omar.ai.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omar.ai.R
import com.omar.ai.ui.OmarStrings
import com.omar.ai.ui.OmarViewModel
import com.omar.ai.ui.theme.CyanAccent
import com.omar.ai.ui.theme.ElectricBlue
import com.omar.ai.ui.theme.SoftIndigo

data class OnboardingItem(
    val icon: ImageVector,
    val titleAr: String,
    val titleEn: String,
    val descAr: String,
    val descEn: String
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(
    viewModel: OmarViewModel
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val isArabic by viewModel.isArabic.collectAsState()
    val isAuthLoading by viewModel.authManager.isAuthLoading.collectAsState()
    val authError by viewModel.authManager.authErrorMessage.collectAsState()
    val phoneCodeSent by viewModel.authManager.phoneCodeSent.collectAsState()

    var showEmailAuth by remember { mutableStateOf(false) }
    var showPhoneAuth by remember { mutableStateOf(false) }
    var phoneInput by remember { mutableStateOf("+20") }
    var smsCodeInput by remember { mutableStateOf("") }
    var phoneLocalError by remember { mutableStateOf<String?>(null) }
    var selectedAuthTab by remember { mutableIntStateOf(0) } // 0 = Sign In, 1 = Sign Up
    var showResetDialog by remember { mutableStateOf(false) }

    // Form states
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var resetEmailInput by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }

    val items = listOf(
        OnboardingItem(
            icon = Icons.Default.Psychology,
            titleAr = "ذكاء اصطناعي فائق وفهم سياقي",
            titleEn = "Advanced Intelligence & Context",
            descAr = "إجابات فورية دقيقة، استيعاب الأخطاء الإملائية، والتعامل مع اللهجات المختلفة بسلاسة.",
            descEn = "Accurate instant answers, natural typo understanding, and fluent multilingual mastery."
        ),
        OnboardingItem(
            icon = Icons.Default.Mic,
            titleAr = "محادثة صوتية ونطق عربي فصيح",
            titleEn = "Interactive Voice & Native Arabic TTS",
            descAr = "تحدث مباشرة بصوتك مع دعم Speech-to-Text ونطق واقعي للإجابات العربية والإنجليزية.",
            descEn = "Real-time voice conversation with native speech recognition and natural text-to-speech."
        ),
        OnboardingItem(
            icon = Icons.Default.LockClock,
            titleAr = "ذاكرة ذكية طويلة المدى",
            titleEn = "Smart Long-term Memory",
            descAr = "يتذكر اهتماماتك ومواعيدك وأحداثك اليومية لتقديم تجربة مخصصة تمامًا مع أمان تام.",
            descEn = "Remembers your goals and context to deliver tailored assistance with complete privacy controls."
        ),
        OnboardingItem(
            icon = Icons.Default.School,
            titleAr = "وضع الدراسة والتعلم",
            titleEn = "Study & Learning Mode",
            descAr = "شرح وتبسيط الدروس، حل المسائل خطوة بخطوة، واختبارات تفاعلية وFlashcards.",
            descEn = "Step-by-step problem solving, lesson summaries, quizzes, and study flashcards."
        ),
        OnboardingItem(
            icon = Icons.Default.Code,
            titleAr = "مساعد البرمجة والعمل التنفيذي",
            titleEn = "Coding & Executive Work",
            descAr = "كتابة الأكواد، تصحيح الأخطاء، توليد الصور والفيديوهات، والتحكم بمهام الهاتف.",
            descEn = "Code generation, debugging, image & video synthesis, and phone tasks automation."
        )
    )

    val pagerState = rememberPagerState(pageCount = { items.size })
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // App Branding Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(ElectricBlue, SoftIndigo, CyanAccent)
                            )
                        )
                        .border(2.dp, CyanAccent.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_omar_logo),
                        contentDescription = "Omar AI Logo",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "OMAR AI",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = 2.sp
                )

                Text(
                    text = if (isArabic) "مساعدك الشخصي الذكي والمتكامل" else "Your Elite Intelligent AI Companion",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Pager Carousel
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) { page ->
                    val item = items[page]
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = if (isArabic) item.titleAr else item.titleEn,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = if (isArabic) item.descAr else item.descEn,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }

                // Pager Indicators
                Row(
                    modifier = Modifier.padding(top = 12.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    repeat(items.size) { index ->
                        val isSelected = pagerState.currentPage == index
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .size(if (isSelected) 18.dp else 6.dp, 6.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Error Display
            val activeError = localError ?: authError
            if (activeError != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Text(
                        text = activeError,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Action Buttons / Form
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Continue with Google Button
                Button(
                    onClick = {
                        localError = null
                        if (activity != null) {
                            viewModel.signInWithGoogle(activity)
                        }
                    },
                    enabled = !isAuthLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    if (isAuthLoading && !showEmailAuth) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = if (isArabic) "التسجيل بحساب Google" else "Continue with Google",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }

                // Email Auth Toggle Button
                OutlinedButton(
                    onClick = {
                        showEmailAuth = !showEmailAuth
                        localError = null
                        viewModel.authManager.clearAuthError()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (showEmailAuth) {
                            if (isArabic) "إخفاء نموذج البريد" else "Hide Email Form"
                        } else {
                            if (isArabic) "تسجيل الدخول / إنشاء حساب بالبريد" else "Sign in / Register with Email"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Phone Auth Toggle
                OutlinedButton(
                    onClick = {
                        showPhoneAuth = !showPhoneAuth
                        showEmailAuth = false
                        phoneLocalError = null
                        viewModel.resetPhoneAuthState()
                        viewModel.authManager.clearAuthError()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (showPhoneAuth) {
                            if (isArabic) "إخفاء تسجيل الهاتف" else "Hide Phone Sign-in"
                        } else {
                            if (isArabic) "تسجيل الدخول برقم الهاتف" else "Sign in with Phone"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Expandable Phone Form
                AnimatedVisibility(visible = showPhoneAuth) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        tonalElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = if (isArabic)
                                    "أدخل رقم هاتفك بالصيغة الدولية ثم رمز SMS"
                                else
                                    "Enter phone in international format, then SMS code",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = phoneInput,
                                onValueChange = { phoneInput = it },
                                label = { Text(if (isArabic) "رقم الهاتف (+20...)" else "Phone (+20...)") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !phoneCodeSent
                            )
                            if (phoneCodeSent) {
                                OutlinedTextField(
                                    value = smsCodeInput,
                                    onValueChange = { smsCodeInput = it.filter { ch -> ch.isDigit() }.take(6) },
                                    label = { Text(if (isArabic) "رمز التحقق (SMS)" else "SMS code") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            phoneLocalError?.let {
                                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                            authError?.let {
                                if (showPhoneAuth) {
                                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            val activity = context as? android.app.Activity
                            Button(
                                onClick = {
                                    phoneLocalError = null
                                    if (!phoneCodeSent) {
                                        if (activity == null) {
                                            phoneLocalError = if (isArabic) "تعذر الوصول للنشاط" else "Activity unavailable"
                                            return@Button
                                        }
                                        viewModel.startPhoneVerification(activity, phoneInput) { ok, err ->
                                            if (!ok) phoneLocalError = err
                                        }
                                    } else {
                                        viewModel.verifyPhoneCode(smsCodeInput) { ok, err ->
                                            if (!ok) phoneLocalError = err
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                enabled = !isAuthLoading
                            ) {
                                if (isAuthLoading && showPhoneAuth) {
                                    CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                                } else {
                                    Text(
                                        text = when {
                                            phoneCodeSent && isArabic -> "تأكيد الرمز والدخول"
                                            phoneCodeSent -> "Verify & Sign in"
                                            isArabic -> "إرسال رمز التحقق"
                                            else -> "Send verification code"
                                        }
                                    )
                                }
                            }
                            if (phoneCodeSent) {
                                TextButton(onClick = {
                                    viewModel.resetPhoneAuthState()
                                    smsCodeInput = ""
                                    phoneLocalError = null
                                    if (activity != null) {
                                        viewModel.startPhoneVerification(activity, phoneInput) { ok, err ->
                                            if (!ok) phoneLocalError = err
                                        }
                                    }
                                }) {
                                    Text(if (isArabic) "إعادة إرسال الرمز" else "Resend code")
                                }
                            }
                        }
                    }
                }

                // Expandable Email Form
                AnimatedVisibility(visible = showEmailAuth) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            TabRow(
                                selectedTabIndex = selectedAuthTab,
                                containerColor = Color.Transparent,
                                contentColor = MaterialTheme.colorScheme.primary
                            ) {
                                Tab(
                                    selected = selectedAuthTab == 0,
                                    onClick = {
                                        selectedAuthTab = 0
                                        localError = null
                                    },
                                    text = { Text(if (isArabic) "تسجيل الدخول" else "Sign In") }
                                )
                                Tab(
                                    selected = selectedAuthTab == 1,
                                    onClick = {
                                        selectedAuthTab = 1
                                        localError = null
                                    },
                                    text = { Text(if (isArabic) "إنشاء حساب" else "Register") }
                                )
                            }

                            if (selectedAuthTab == 1) {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    label = { Text(if (isArabic) "الاسم" else "Full Name") },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }

                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = { emailInput = it },
                                label = { Text(if (isArabic) "البريد الإلكتروني" else "Email") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text(if (isArabic) "كلمة المرور" else "Password") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null
                                        )
                                    }
                                },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            if (selectedAuthTab == 1) {
                                OutlinedTextField(
                                    value = confirmPasswordInput,
                                    onValueChange = { confirmPasswordInput = it },
                                    label = { Text(if (isArabic) "تأكيد كلمة المرور" else "Confirm Password") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }

                            if (selectedAuthTab == 0) {
                                TextButton(
                                    onClick = {
                                        resetEmailInput = emailInput
                                        showResetDialog = true
                                    },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text(
                                        text = if (isArabic) "نسيت كلمة المرور؟" else "Forgot Password?",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    localError = null
                                    if (selectedAuthTab == 0) {
                                        viewModel.signInWithEmail(emailInput, passwordInput) { success, err ->
                                            if (!success) {
                                                localError = err
                                            }
                                        }
                                    } else {
                                        viewModel.signUpWithEmail(nameInput, emailInput, passwordInput, confirmPasswordInput) { success, err ->
                                            if (!success) {
                                                localError = err
                                            }
                                        }
                                    }
                                },
                                enabled = !isAuthLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (isAuthLoading && showEmailAuth) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text(
                                        text = if (selectedAuthTab == 0) {
                                            if (isArabic) "دخول" else "Sign In"
                                        } else {
                                            if (isArabic) "تسجيل حساب" else "Register"
                                        },
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Continue as Guest Button
                TextButton(
                    onClick = { viewModel.continueAsGuest() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    Text(
                        text = if (isArabic) "المتابعة كضيف" else "Continue as Guest",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = OmarStrings.guestModeNotice(isArabic),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    // Password Reset Dialog
    if (showResetDialog) {
        var resetResultMsg by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Text(if (isArabic) "إعادة تعيين كلمة المرور" else "Reset Password")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (isArabic) "أدخل بريدك الإلكتروني وسنرسل لك رابطًا لإعادة تعيين كلمة المرور:"
                        else "Enter your registered email address to receive reset instructions:"
                    )
                    OutlinedTextField(
                        value = resetEmailInput,
                        onValueChange = { resetEmailInput = it },
                        label = { Text(if (isArabic) "البريد الإلكتروني" else "Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (resetResultMsg != null) {
                        Text(
                            text = resetResultMsg!!,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.sendPasswordReset(resetEmailInput) { _, message ->
                            resetResultMsg = message
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                        }
                    }
                ) {
                    Text(if (isArabic) "إرسال الرابط" else "Send Reset Link")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(if (isArabic) "إغلاق" else "Close")
                }
            }
        )
    }
}

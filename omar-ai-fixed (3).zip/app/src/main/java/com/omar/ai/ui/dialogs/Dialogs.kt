package com.omar.ai.ui.dialogs

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omar.ai.data.auth.UserProfile
import com.omar.ai.data.local.MemoryEntity
import com.omar.ai.data.local.TodoEntity
import com.omar.ai.data.model.ContactMatch
import com.omar.ai.ui.OmarStrings

@Composable
fun ContactCallConfirmationDialog(
    isArabic: Boolean,
    contactMatches: List<ContactMatch>,
    targetName: String,
    onConfirm: (ContactMatch) -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        icon = {
            Icon(
                imageVector = Icons.Default.Phone,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = if (contactMatches.size == 1) {
                    OmarStrings.callContactConfirm(isArabic, contactMatches.first().name)
                } else if (contactMatches.isEmpty()) {
                    if (isArabic) "لم يتم العثور على جهة اتصال باسم \"$targetName\""
                    else "No contact found for \"$targetName\""
                } else {
                    if (isArabic) "اختر الرقم المطلوب للاتصال بـ $targetName:"
                    else "Select number to call $targetName:"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            if (contactMatches.isEmpty()) {
                Text(
                    text = if (isArabic) "يُرجى التحقق من صلاحية الوصول إلى جهات الاتصال أو صحة الاسم."
                    else "Please check contacts permission or name spelling."
                )
            } else {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(contactMatches) { contact ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onConfirm(contact) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = contact.name, fontWeight = FontWeight.Bold)
                                    Text(text = contact.phoneNumber, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (contactMatches.size == 1) {
                Button(onClick = { onConfirm(contactMatches.first()) }) {
                    Text(OmarStrings.call(isArabic))
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) {
                Text(OmarStrings.cancel(isArabic))
            }
        }
    )
}

@Composable
fun MemoryManagerDialog(
    isArabic: Boolean,
    memories: List<MemoryEntity>,
    onAddMemory: (String, String, String) -> Unit,
    onDeleteMemory: (Long) -> Unit,
    onClearAll: () -> Unit,
    onDismiss: () -> Unit
) {
    var showAddRow by remember { mutableStateOf(false) }
    var newKey by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = OmarStrings.memory(isArabic),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { showAddRow = !showAddRow }) {
                    Icon(Icons.Default.Add, contentDescription = "Add", tint = MaterialTheme.colorScheme.primary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = OmarStrings.memoryDesc(isArabic),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (showAddRow) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            OutlinedTextField(
                                value = newKey,
                                onValueChange = { newKey = it },
                                placeholder = { Text(OmarStrings.memoryKey(isArabic), fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = newContent,
                                onValueChange = { newContent = it },
                                placeholder = { Text(OmarStrings.memoryValue(isArabic), fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    if (newKey.isNotBlank() && newContent.isNotBlank()) {
                                        onAddMemory(newKey, newContent, "general")
                                        newKey = ""
                                        newContent = ""
                                        showAddRow = false
                                    }
                                },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text(if (isArabic) "حفظ بالذاكرة" else "Save Memory")
                            }
                        }
                    }
                }

                if (memories.isEmpty()) {
                    Text(
                        text = if (isArabic) "لا توجد معلومات محفوظة في الذاكرة بعد."
                        else "No memories stored yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.height(280.dp)) {
                        items(memories, key = { it.id }) { mem ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = mem.key, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        Text(text = mem.content, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    IconButton(
                                        onClick = { onDeleteMemory(mem.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isArabic) "إغلاق" else "Close")
            }
        },
        dismissButton = {
            if (memories.isNotEmpty()) {
                TextButton(onClick = onClearAll) {
                    Text(OmarStrings.clearAll(isArabic), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    )
}

@Composable
fun TodoManagerDialog(
    isArabic: Boolean,
    todos: List<TodoEntity>,
    onAddTodo: (String) -> Unit,
    onToggleTodo: (Long, Boolean) -> Unit,
    onDeleteTodo: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var newTaskText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = OmarStrings.todos(isArabic),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Add new todo row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newTaskText,
                        onValueChange = { newTaskText = it },
                        placeholder = { Text(OmarStrings.addTodo(isArabic), fontSize = 13.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (newTaskText.isNotBlank()) {
                                onAddTodo(newTaskText)
                                newTaskText = ""
                            }
                        }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (todos.isEmpty()) {
                    Text(
                        text = if (isArabic) "لا توجد مهام حالية." else "No active tasks.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.height(280.dp)) {
                        items(todos, key = { it.id }) { todo ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = todo.isCompleted,
                                    onCheckedChange = { onToggleTodo(todo.id, it) },
                                    colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                                )
                                Text(
                                    text = todo.title,
                                    textDecoration = if (todo.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                                    color = if (todo.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onDeleteTodo(todo.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isArabic) "إغلاق" else "Close")
            }
        }
    )
}

@Composable
fun SettingsDialog(
    isArabic: Boolean,
    currentUser: UserProfile?,
    themeMode: String,
    autoSpeak: Boolean,
    voiceSpeed: Float,
    smartSyncEnabled: Boolean = true,
    onSetLanguage: (Boolean) -> Unit,
    onSetThemeMode: (String) -> Unit,
    onSetAutoSpeak: (Boolean) -> Unit,
    onSetVoiceSpeed: (Float) -> Unit,
    onSetSmartSync: (Boolean) -> Unit = {},
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var speedState by remember { mutableFloatStateOf(voiceSpeed) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = OmarStrings.settings(isArabic),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                // Language Selection
                item {
                    Text(
                        text = OmarStrings.language(isArabic),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onSetLanguage(true) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isArabic) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                "العربية",
                                color = if (isArabic) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Button(
                            onClick = { onSetLanguage(false) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isArabic) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                "English",
                                color = if (!isArabic) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                }

                // Theme Selection
                item {
                    Text(
                        text = OmarStrings.theme(isArabic),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ThemeOptionButton(
                            label = OmarStrings.themeDark(isArabic),
                            isSelected = themeMode == "DARK",
                            onClick = { onSetThemeMode("DARK") },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeOptionButton(
                            label = OmarStrings.themeLight(isArabic),
                            isSelected = themeMode == "LIGHT",
                            onClick = { onSetThemeMode("LIGHT") },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeOptionButton(
                            label = OmarStrings.themeSystem(isArabic),
                            isSelected = themeMode == "SYSTEM",
                            onClick = { onSetThemeMode("SYSTEM") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                }

                // Auto Speak Toggle
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = OmarStrings.autoSpeak(isArabic), fontWeight = FontWeight.Bold)
                            Text(
                                text = if (isArabic) "نطق إجابات المساعد تلقائيًا بالصوت" else "Speak AI responses automatically",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = autoSpeak, onCheckedChange = onSetAutoSpeak)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                }

                // Voice Speed
                item {
                    Text(text = "${OmarStrings.voiceSpeed(isArabic)} (${String.format("%.2f", speedState)}x)", fontWeight = FontWeight.Bold)
                    Slider(
                        value = speedState,
                        onValueChange = { speedState = it },
                        onValueChangeFinished = { onSetVoiceSpeed(speedState) },
                        valueRange = 0.5f..1.75f
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                }

                // Set Default Digital Assistant Intent
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(text = OmarStrings.defaultAssistant(isArabic), fontWeight = FontWeight.Bold)
                        Text(
                            text = OmarStrings.defaultAssistantDesc(isArabic),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        OutlinedButton(
                            onClick = {
                                try {
                                    val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(intent)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(OmarStrings.defaultAssistant(isArabic))
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                }

                // Privacy & Terms
                item {
                    Text(text = OmarStrings.privacyTerms(isArabic), fontWeight = FontWeight.Bold)
                    Text(
                        text = if (isArabic)
                            "Omar AI يحترم خصوصيتك بالكامل. يتم تشفير الاتصال، ولا تتم مشاركة محادثاتك أو صورك مع أطراف ثالثة. يمكنك حذف جميع بياناتك في أي وقت."
                        else
                            "Omar AI fully respects your privacy. All traffic is encrypted and your data is never shared. You can delete all your conversations and memories anytime.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                }

                // Sign out & Delete Account
                
                item {
                    Text(
                        text = if (isArabic) "المزامنة الذكية" else "Smart Sync",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isArabic)
                                "مزامنة المحادثات والذاكرة مع حساب Google"
                            else
                                "Sync chats & memory with Google account",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = smartSyncEnabled,
                            onCheckedChange = onSetSmartSync
                        )
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                }

item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onSignOut,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(OmarStrings.signOut(isArabic))
                        }
                        Button(
                            onClick = { showDeleteConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(OmarStrings.deleteAccount(isArabic))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isArabic) "تم" else "Done")
            }
        }
    )

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text(OmarStrings.deleteAccount(isArabic)) },
            text = {
                Text(
                    text = if (isArabic) "هل أنت متأكد من رغبتك في حذف جميع المحادثات، الذاكرة، والبيانات؟ لا يمكن التراجع عن هذا الإجراء."
                    else "Are you sure you want to delete all chats, memory, and data? This action cannot be undone."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteAccount()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(OmarStrings.delete(isArabic))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(OmarStrings.cancel(isArabic))
                }
            }
        )
    }
}

@Composable
fun ThemeOptionButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = modifier
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            maxLines = 1,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}

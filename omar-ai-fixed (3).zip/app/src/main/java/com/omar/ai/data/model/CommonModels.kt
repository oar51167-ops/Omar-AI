package com.omar.ai.data.model

enum class Role {
    USER,
    ASSISTANT,
    SYSTEM
}

enum class MessageStatus {
    PENDING,
    SUCCESS,
    ERROR
}

enum class AssistantMode(val titleAr: String, val titleEn: String, val icon: String) {
    GENERAL("عام", "General", "✨"),
    STUDY("دراسة", "Study", "📚"),
    CODING("برمجة", "Coding", "💻"),
    WORK("عمل", "Work", "💼")
}

data class ContactMatch(
    val id: String,
    val name: String,
    val phoneNumber: String
)

data class ActionCall(
    val actionType: String,
    val title: String,
    val parameters: Map<String, String> = emptyMap(),
    val requiresConfirmation: Boolean = false,
    val executed: Boolean = false
)

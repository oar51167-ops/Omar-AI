package com.omar.ai.ui

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.omar.ai.data.action.ActionDispatcher
import com.omar.ai.data.ai.AIProvider
import com.omar.ai.data.ai.GeminiAIProvider
import com.omar.ai.data.auth.AuthManager
import com.omar.ai.data.auth.UserProfile
import com.omar.ai.data.local.ChatMessageEntity
import com.omar.ai.data.local.ConversationEntity
import com.omar.ai.data.local.MemoryEntity
import com.omar.ai.data.local.OmarDatabase
import com.omar.ai.data.local.ReminderEntity
import com.omar.ai.data.local.TodoEntity
import com.omar.ai.data.memory.MemoryEngine
import com.omar.ai.data.sync.SmartSyncManager
import com.omar.ai.data.model.ActionCall
import com.omar.ai.data.model.AssistantMode
import com.omar.ai.data.model.ContactMatch
import com.omar.ai.data.model.MessageStatus
import com.omar.ai.data.model.Role
import com.omar.ai.data.voice.VoiceManager
import com.omar.ai.data.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

class OmarViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context = application.applicationContext
    private val database = OmarDatabase.getDatabase(context)
    private val dao = database.omarDao()

    private val aiProvider: AIProvider = GeminiAIProvider()
    val actionDispatcher = ActionDispatcher(context, dao)
    val voiceManager = VoiceManager(context)
    val authManager = AuthManager(context, dao)
    val memoryEngine = MemoryEngine(context, dao)
    val syncManager = SmartSyncManager(context, dao)

    private val prefs: SharedPreferences =
        context.getSharedPreferences("omar_ai_settings", Context.MODE_PRIVATE)

    // Language & Theme Settings
    private val _isArabic = MutableStateFlow(prefs.getBoolean("is_arabic", true))
    val isArabic: StateFlow<Boolean> = _isArabic.asStateFlow()

    private val _themeMode = MutableStateFlow(prefs.getString("theme_mode", "DARK") ?: "DARK")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _autoSpeak = MutableStateFlow(prefs.getBoolean("auto_speak", false))
    val autoSpeak: StateFlow<Boolean> = _autoSpeak.asStateFlow()

    private val _voiceSpeed = MutableStateFlow(prefs.getFloat("voice_speed", 1.0f))
    val voiceSpeed: StateFlow<Float> = _voiceSpeed.asStateFlow()

    // Mode
    private val _selectedMode = MutableStateFlow(AssistantMode.GENERAL)
    val selectedMode: StateFlow<AssistantMode> = _selectedMode.asStateFlow()

    // Conversations & Messages
    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId: StateFlow<String?> = _currentConversationId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val currentUser: StateFlow<UserProfile?> = authManager.currentUser

    /** Firebase / Google UID used to scope all local data per account */
    private fun currentUserId(): String =
        authManager.currentUser.value?.uid ?: "guest_local"

    val conversations: StateFlow<List<ConversationEntity>> = combine(
        currentUser,
        _searchQuery
    ) { user, query ->
        Pair(user?.uid ?: "guest_local", query)
    }.flatMapLatest { (uid, query) ->
        if (query.isBlank()) dao.getActiveConversations(uid)
        else dao.searchConversations(uid, query)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentMessages.asStateFlow()

    // Long-Term Memories & Todos & Reminders – scoped to signed-in Google/email account
    val memories: StateFlow<List<MemoryEntity>> = currentUser.flatMapLatest { user ->
        dao.getAllMemories(user?.uid ?: "guest_local")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todos: StateFlow<List<TodoEntity>> = currentUser.flatMapLatest { user ->
        dao.getAllTodos(user?.uid ?: "guest_local")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<ReminderEntity>> = currentUser.flatMapLatest { user ->
        dao.getActiveReminders(user?.uid ?: "guest_local")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Generation & Streaming State
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingText = MutableStateFlow("")
    val streamingText: StateFlow<String> = _streamingText.asStateFlow()

    // Attached Media
    private val _attachedImageBase64 = MutableStateFlow<String?>(null)
    val attachedImageBase64: StateFlow<String?> = _attachedImageBase64.asStateFlow()

    private val _attachedImageUri = MutableStateFlow<String?>(null)
    val attachedImageUri: StateFlow<String?> = _attachedImageUri.asStateFlow()

    private val _attachedFileName = MutableStateFlow<String?>(null)
    val attachedFileName: StateFlow<String?> = _attachedFileName.asStateFlow()

    private val _attachedMediaType = MutableStateFlow<String?>(null)
    val attachedMediaType: StateFlow<String?> = _attachedMediaType.asStateFlow()

    // Action Confirmation
    private val _pendingActionCall = MutableStateFlow<ActionCall?>(null)
    val pendingActionCall: StateFlow<ActionCall?> = _pendingActionCall.asStateFlow()

    private val _contactMatches = MutableStateFlow<List<ContactMatch>>(emptyList())
    val contactMatches: StateFlow<List<ContactMatch>> = _contactMatches.asStateFlow()

    // Voice
    val voiceState: StateFlow<VoiceState> = voiceManager.voiceState
    val syncState = syncManager.syncState
    val lastSyncMessage = syncManager.lastSyncMessage
    val liveSpokenText: StateFlow<String> = voiceManager.liveSpokenText

    private val _voiceError = MutableStateFlow<String?>(null)
    val voiceError: StateFlow<String?> = _voiceError.asStateFlow()
    fun clearVoiceError() { _voiceError.value = null }

    init {
        viewModelScope.launch {
            // Clean up temporary conversations from previous app session
            try {
                dao.deleteTemporaryConversations(currentUserId())
            } catch (_: Exception) { }

            // Observe messages with flatMapLatest so switching chats cancels previous collector
            // (old nested collect blocked forever and stopped saving/updating replies in UI)
            _currentConversationId
                .flatMapLatest { convId ->
                    if (convId != null) dao.getMessagesForConversation(convId)
                    else flowOf(emptyList())
                }
                .collect { msgList ->
                    _currentMessages.value = msgList
                }
        }
    }

    fun setLanguage(arabic: Boolean) {
        _isArabic.value = arabic
        prefs.edit().putBoolean("is_arabic", arabic).apply()
    }

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode).apply()
    }

    fun setAutoSpeak(enabled: Boolean) {
        _autoSpeak.value = enabled
        prefs.edit().putBoolean("auto_speak", enabled).apply()
    }

    fun setVoiceSpeed(speed: Float) {
        _voiceSpeed.value = speed
        prefs.edit().putFloat("voice_speed", speed).apply()
    }

    fun setMode(mode: AssistantMode) {
        _selectedMode.value = mode
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun startNewConversation(isTemporary: Boolean = false) {
        val newId = UUID.randomUUID().toString()
        val title = if (_isArabic.value) "محادثة جديدة" else "New Conversation"
        val uid = currentUserId()
        val conv = ConversationEntity(
            id = newId,
            userId = uid,
            title = title,
            isTemporary = isTemporary,
            mode = _selectedMode.value.name
        )
        viewModelScope.launch {
            dao.insertConversation(conv)
            _currentConversationId.value = newId
            if (!isTemporary) syncManager.schedulePush(uid)
        }
    }

    fun selectConversation(id: String) {
        _currentConversationId.value = id
    }

    fun renameConversation(id: String, newTitle: String) {
        viewModelScope.launch {
            dao.updateConversationTitle(id, currentUserId(), newTitle)
        }
    }

    fun togglePinConversation(id: String, currentPinned: Boolean) {
        viewModelScope.launch {
            dao.setConversationPinned(id, currentUserId(), !currentPinned)
        }
    }

    fun archiveConversation(id: String) {
        viewModelScope.launch {
            dao.setConversationArchived(id, currentUserId(), true)
            if (_currentConversationId.value == id) {
                _currentConversationId.value = null
            }
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            val uid = currentUserId()
            dao.deleteConversation(id, uid)
            dao.deleteMessagesForConversation(id)
            syncManager.deleteConversationRemote(uid, id)
            if (_currentConversationId.value == id) {
                _currentConversationId.value = null
            }
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            val uid = currentUserId()
            dao.clearAllConversations(uid)
            dao.clearAllMessages(uid)
            _currentConversationId.value = null
        }
    }

    fun attachImage(uri: Uri?) {
        if (uri == null) {
            clearAttachedMedia()
            return
        }
        _attachedImageUri.value = uri.toString()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val mime = resolver.getType(uri) ?: "application/octet-stream"
                _attachedMediaType.value = mime

                // Resolve display name
                var displayName = "file"
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && nameIndex >= 0) {
                        displayName = cursor.getString(nameIndex) ?: displayName
                    }
                }
                _attachedFileName.value = displayName

                if (mime.startsWith("image/")) {
                    resolver.openInputStream(uri)?.use { stream ->
                        val bitmap = BitmapFactory.decodeStream(stream)
                        if (bitmap != null) {
                            val outputStream = ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
                            val base64 = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
                            _attachedImageBase64.value = base64
                        }
                    }
                } else {
                    // Non-image: keep URI + metadata. Optionally extract text for text-like files.
                    _attachedImageBase64.value = null
                    if (mime.startsWith("text/") || mime == "application/json" ||
                        displayName.endsWith(".txt", true) || displayName.endsWith(".md", true) ||
                        displayName.endsWith(".csv", true) || displayName.endsWith(".log", true)
                    ) {
                        resolver.openInputStream(uri)?.use { stream ->
                            val text = stream.bufferedReader().readText().take(12000)
                            // Store extracted text in fileName field prefix so AI can see it via dispatch
                            _attachedFileName.value = "$displayName\n---\n$text"
                        }
                    }
                    // APK / IPA / EXE / PDF / Word / IPK etc. are attached as metadata only
                    // (content is not executed – only described to the model)
                }
            } catch (e: Exception) {
                Log.e("OmarViewModel", "Failed to process attachment", e)
            }
        }
    }

    fun clearAttachedImage() {
        clearAttachedMedia()
    }

    fun clearAttachedMedia() {
        _attachedImageUri.value = null
        _attachedImageBase64.value = null
        _attachedMediaType.value = null
        _attachedFileName.value = null
    }

    fun attachDocument(uri: Uri?, name: String, type: String) {
        if (uri == null) {
            clearAttachedMedia()
            return
        }
        _attachedImageUri.value = uri.toString()
        _attachedFileName.value = name
        _attachedMediaType.value = type
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isBlank() && _attachedImageBase64.value == null && _attachedImageUri.value == null) return

        var activeConvId = _currentConversationId.value
        if (activeConvId == null) {
            activeConvId = UUID.randomUUID().toString()
            val newConv = ConversationEntity(
                id = activeConvId,
                userId = currentUserId(),
                title = trimmed.take(25).ifBlank { if (_isArabic.value) "محادثة وسائط" else "Media Chat" },
                mode = _selectedMode.value.name
            )
            viewModelScope.launch {
                dao.insertConversation(newConv)
                _currentConversationId.value = activeConvId
                dispatchMessageToAI(
                    activeConvId,
                    trimmed,
                    _attachedImageBase64.value,
                    _attachedImageUri.value,
                    _attachedMediaType.value,
                    _attachedFileName.value
                )
            }
            clearAttachedMedia()
            return
        }

        dispatchMessageToAI(
            activeConvId,
            trimmed,
            _attachedImageBase64.value,
            _attachedImageUri.value,
            _attachedMediaType.value,
            _attachedFileName.value
        )
        clearAttachedMedia()
    }

    private fun dispatchMessageToAI(
        convId: String,
        userText: String,
        userImgBase64: String?,
        userImgUri: String?,
        mediaType: String? = null,
        fileName: String? = null
    ) {
        val userMsgId = UUID.randomUUID().toString()
        val uid = currentUserId()
        val userMsg = ChatMessageEntity(
            id = userMsgId,
            conversationId = convId,
            userId = uid,
            role = Role.USER.name,
            content = userText,
            imageBase64 = userImgBase64,
            imageUri = userImgUri,
            videoUri = null,
            mediaType = mediaType,
            fileName = fileName,
            status = MessageStatus.SUCCESS.name
        )

        val assistantMsgId = UUID.randomUUID().toString()
        val assistantPendingMsg = ChatMessageEntity(
            id = assistantMsgId,
            conversationId = convId,
            userId = uid,
            role = Role.ASSISTANT.name,
            content = "",
            status = MessageStatus.PENDING.name
        )

        viewModelScope.launch {
            dao.insertMessage(userMsg)
            dao.insertMessage(assistantPendingMsg)
            _isGenerating.value = true

            // Automatically extract facts/events into long-term memory
            if (userText.isNotBlank()) {
                memoryEngine.learnFromUserMessage(userText, _isArabic.value, currentUserId())
            }

            val history = dao.getMessagesListForConversation(convId)
                .filter { it.id != assistantMsgId }
            val memoriesList = dao.getMemoriesList(currentUserId())

            // Enrich prompt when a non-image file is attached (APK, PDF, Word, EXE, IPA, etc.)
            val enrichedUserMessage = buildString {
                append(userText)
                if (!fileName.isNullOrBlank() || !mediaType.isNullOrBlank()) {
                    if (isNotEmpty()) append("\n\n")
                    append("[Attached file]\n")
                    append("Name: ${fileName?.substringBefore("\n---\n") ?: "unknown"}\n")
                    append("MIME: ${mediaType ?: "unknown"}\n")
                    if (fileName?.contains("\n---\n") == true) {
                        append("Content excerpt:\n")
                        append(fileName.substringAfter("\n---\n").take(8000))
                    } else if (!mediaType.isNullOrBlank() && !mediaType.startsWith("image/")) {
                        append("Note: Binary/document attachment. Describe or advise based on filename and type only. Do not claim to have executed the file.")
                    }
                }
            }.ifBlank { userText.ifBlank { "Analyze the attached file." } }

            val aiResponse = aiProvider.generateResponse(
                conversationHistory = history,
                userMessage = enrichedUserMessage,
                userImageBase64 = userImgBase64,
                mode = _selectedMode.value,
                longTermMemories = memoriesList
            )

            _isGenerating.value = false

            // Update assistant message with final result
            val updatedAssistantMsg = assistantPendingMsg.copy(
                content = aiResponse.text,
                imageBase64 = aiResponse.generatedImageBase64,
                videoUri = aiResponse.generatedVideoUri,
                actionType = aiResponse.actionCall?.actionType,
                actionParamsJson = aiResponse.actionCall?.parameters?.toString(),
                suggestionsJson = if (aiResponse.suggestions.isNotEmpty()) aiResponse.suggestions.joinToString("|||") else null,
                status = if (aiResponse.isError) MessageStatus.ERROR.name else MessageStatus.SUCCESS.name
            )
            dao.updateMessage(updatedAssistantMsg)
            // Force UI refresh in case Flow emission is delayed
            _currentMessages.value = dao.getMessagesListForConversation(convId)

            // Auto-speak if enabled
            if (_autoSpeak.value && !aiResponse.isError && aiResponse.text.isNotBlank()) {
                voiceManager.speak(aiResponse.text, _voiceSpeed.value)
            }

            // Handle Phone Action if triggered
            if (aiResponse.actionCall != null) {
                handleTriggeredAction(aiResponse.actionCall)
            }

            // Generate AI Title if first turn
            val uid = currentUserId()
            if (history.size <= 1) {
                val smartTitle = aiProvider.generateTitle(userText)
                dao.updateConversationTitle(convId, uid, smartTitle)
                dao.touchConversation(convId, uid)
            } else {
                dao.touchConversation(convId, uid)
            }

            // Smart sync: push this conversation + messages to cloud (Google account)
            val conv = dao.getConversationById(convId, uid)
            val msgs = dao.getMessagesListForConversation(convId)
            if (conv != null && !conv.isTemporary) {
                syncManager.pushConversationNow(uid, conv, msgs)
            }
            syncManager.schedulePush(uid)
        }
    }

    private fun handleTriggeredAction(action: ActionCall) {
        if (action.actionType == "CALL_CONTACT") {
            val name = action.parameters["name"] ?: ""
            val matches = actionDispatcher.searchContacts(name)
            _contactMatches.value = matches
            _pendingActionCall.value = action
        } else {
            viewModelScope.launch {
                actionDispatcher.executeAction(action)
            }
        }
    }

    fun confirmContactCall(contact: ContactMatch) {
        actionDispatcher.startDialer(contact.phoneNumber)
        _pendingActionCall.value = null
        _contactMatches.value = emptyList()
    }

    fun cancelPendingAction() {
        _pendingActionCall.value = null
        _contactMatches.value = emptyList()
    }

    fun regenerateLastResponse() {
        val convId = _currentConversationId.value ?: return
        viewModelScope.launch {
            val messages = dao.getMessagesListForConversation(convId)
            val lastUserMsg = messages.lastOrNull { it.role == Role.USER.name }
            val lastAssistantMsg = messages.lastOrNull { it.role == Role.ASSISTANT.name }
            if (lastUserMsg != null && lastAssistantMsg != null) {
                dao.deleteMessage(lastAssistantMsg.id)
                dispatchMessageToAI(
                    convId,
                    lastUserMsg.content,
                    lastUserMsg.imageBase64,
                    lastUserMsg.imageUri
                )
            }
        }
    }

    fun editUserMessage(messageId: String, newContent: String) {
        val convId = _currentConversationId.value ?: return
        viewModelScope.launch {
            dao.updateMessageContent(messageId, newContent, MessageStatus.SUCCESS.name)
            // Delete subsequent messages and regenerate
            val allMessages = dao.getMessagesListForConversation(convId)
            val editedIndex = allMessages.indexOfFirst { it.id == messageId }
            if (editedIndex >= 0) {
                for (i in editedIndex + 1 until allMessages.size) {
                    dao.deleteMessage(allMessages[i].id)
                }
                val editedMsg = allMessages[editedIndex]
                dispatchMessageToAI(convId, newContent, editedMsg.imageBase64, editedMsg.imageUri)
            }
        }
    }

    fun deleteMessage(id: String) {
        viewModelScope.launch {
            dao.deleteMessage(id)
        }
    }


    /** Call after Google / Email sign-in succeeds to restore cloud data. */
    fun syncPullOnLogin() {
        val uid = currentUserId()
        if (!uid.startsWith("guest")) {
            syncManager.pullOnLogin(uid)
        }
    }

    fun setSmartSyncEnabled(enabled: Boolean) {
        syncManager.setEnabled(enabled)
    }

    fun isSmartSyncEnabled(): Boolean = syncManager.isEnabled()

    fun startVoiceListening() {
        _voiceError.value = null
        // Prefer Arabic STT; English still works for mixed speech on most devices
        val preferred = if (_isArabic.value) "ar-SA" else "en-US"
        voiceManager.startListening(
            languageCode = preferred,
            onFinalResult = { spokenText ->
                if (spokenText.isNotBlank()) {
                    // Ensure we speak the AI reply after voice input
                    if (!_autoSpeak.value) {
                        _autoSpeak.value = true
                        prefs.edit().putBoolean("auto_speak", true).apply()
                    }
                    sendMessage(spokenText)
                }
            },
            onError = { error ->
                Log.w("OmarViewModel", "Voice error: $error")
                _voiceError.value = error
            }
        )
    }

    fun stopVoiceListening() {
        voiceManager.stopListening()
    }

    fun speakText(text: String) {
        voiceManager.speak(text, _voiceSpeed.value)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    // Memories
    fun addMemory(key: String, content: String, category: String = "general") {
        viewModelScope.launch {
            val uid = currentUserId()
            val mem = MemoryEntity(userId = uid, key = key, content = content, category = category)
            val newId = dao.insertMemory(mem)
            syncManager.pushMemoryNow(uid, mem.copy(id = newId))
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            val uid = currentUserId()
            dao.deleteMemory(id, uid)
            syncManager.deleteMemoryRemote(uid, id, "")
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            dao.clearAllMemories(currentUserId())
        }
    }

    // To-dos
    fun addTodo(title: String, category: String = "عام") {
        viewModelScope.launch {
            dao.insertTodo(TodoEntity(userId = currentUserId(), title = title, category = category))
        }
    }

    fun toggleTodo(id: Long, completed: Boolean) {
        viewModelScope.launch {
            dao.toggleTodo(id, currentUserId(), completed)
        }
    }

    fun deleteTodo(id: Long) {
        viewModelScope.launch {
            dao.deleteTodo(id, currentUserId())
        }
    }

    // Auth
    fun continueAsGuest() {
        authManager.continueAsGuest()
    }


    fun startPhoneVerification(activity: android.app.Activity, phoneE164: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = authManager.startPhoneVerification(activity, phoneE164)
            if (res.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.localizedMessage ?: authManager.authErrorMessage.value)
            }
        }
    }

    fun verifyPhoneCode(smsCode: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = authManager.verifyPhoneCode(smsCode)
            if (res.isSuccess) {
                syncPullOnLogin()
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.localizedMessage ?: authManager.authErrorMessage.value)
            }
        }
    }

    fun resetPhoneAuthState() {
        authManager.resetPhoneAuthState()
    }

    fun signInWithGoogle(activityContext: Context) {
        viewModelScope.launch {
            val result = authManager.signInWithGoogleCredential(activityContext)
            if (result.isSuccess) {
                syncPullOnLogin()
            }
            // Errors are already published on authManager.authErrorMessage for the UI
        }
    }

    fun signInWithEmail(email: String, pass: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = authManager.signInWithEmail(email, pass)
            if (res.isSuccess) {
                syncPullOnLogin()
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.localizedMessage)
            }
        }
    }

    fun signUpWithEmail(name: String, email: String, pass: String, confirmPass: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = authManager.signUpWithEmail(name, email, pass, confirmPass)
            if (res.isSuccess) {
                syncPullOnLogin()
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.localizedMessage)
            }
        }
    }

    fun sendPasswordReset(email: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = authManager.sendPasswordReset(email)
            if (res.isSuccess) {
                onResult(true, res.getOrDefault("تم إرسال رابط إعادة تعيين كلمة المرور"))
            } else {
                onResult(false, res.exceptionOrNull()?.localizedMessage ?: "حدث خطأ أثناء الإرسال")
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            authManager.signOut()
            _currentConversationId.value = null
            _currentMessages.value = emptyList()
        }
    }

    fun deleteAccountAndData() {
        viewModelScope.launch {
            authManager.deleteAccountAndData()
            _currentConversationId.value = null
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}

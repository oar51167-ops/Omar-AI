package com.omar.ai.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.omar.ai.data.model.AssistantMode
import com.omar.ai.data.model.MessageStatus

@Entity(
    tableName = "conversations",
    indices = [Index(value = ["userId"]), Index(value = ["userId", "updatedAt"])]
)
data class ConversationEntity(
    @PrimaryKey
    val id: String,
    val userId: String = "",
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val isTemporary: Boolean = false,
    val isArchived: Boolean = false,
    val mode: String = AssistantMode.GENERAL.name
)

@Entity(
    tableName = "chat_messages",
    indices = [Index(value = ["conversationId"]), Index(value = ["userId"])]
)
data class ChatMessageEntity(
    @PrimaryKey
    val id: String,
    val conversationId: String,
    val userId: String = "",
    val role: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imageBase64: String? = null,
    val imageUri: String? = null,
    val actionType: String? = null,
    val actionParamsJson: String? = null,
    val actionExecuted: Boolean = false,
    val suggestionsJson: String? = null,
    val videoUri: String? = null,
    val mediaType: String? = null,
    val fileName: String? = null,
    val status: String = MessageStatus.SUCCESS.name
)

@Entity(
    tableName = "memories",
    indices = [Index(value = ["userId"]), Index(value = ["userId", "key"], unique = true)]
)
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String = "",
    val key: String,
    val content: String,
    val category: String = "general",
    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "todos",
    indices = [Index(value = ["userId"])]
)
data class TodoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String = "",
    val title: String,
    val isCompleted: Boolean = false,
    val category: String = "عام",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "reminders",
    indices = [Index(value = ["userId"])]
)
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: String = "",
    val title: String,
    val triggerTimeMillis: Long,
    val isTriggered: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

package com.omar.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Primary AI Brand Colors
val CyanAccent = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF0EA5E9)
val DeepSapphire = Color(0xFF0284C7)
val SoftIndigo = Color(0xFF818CF8)
val DeepIndigo = Color(0xFF4F46E5)
val EmeraldSuccess = Color(0xFF10B981)
val CoralWarning = Color(0xFFF43F5E)

// Dark Theme Colors
val DarkBackground = Color(0xFF080C14)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkSurfaceHighlight = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF1E293B)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightSurfaceHighlight = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
val LightBorder = Color(0xFFE2E8F0)

// Code block theme
val CodeBackground = Color(0xFF0B101D)
val CodeText = Color(0xFF38BDF8)
val CodeComment = Color(0xFF64748B)
val CodeKeyword = Color(0xFFF472B6)
val CodeString = Color(0xFFA7F3D0)

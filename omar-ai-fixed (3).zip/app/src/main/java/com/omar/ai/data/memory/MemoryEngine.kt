package com.omar.ai.data.memory

import android.content.Context
import android.content.SharedPreferences
import com.omar.ai.data.local.MemoryEntity
import com.omar.ai.data.local.OmarDao
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MemoryEngine(
    private val context: Context,
    private val dao: OmarDao
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("omar_ai_memory_prefs", Context.MODE_PRIVATE)

    var isMemoryEnabled: Boolean
        get() = prefs.getBoolean("is_memory_enabled", true)
        set(value) = prefs.edit().putBoolean("is_memory_enabled", value).apply()

    private val timeFormatAr = SimpleDateFormat("hh:mm a", Locale("ar"))
    private val dateFormatAr = SimpleDateFormat("dd/MM/yyyy", Locale("ar"))
    private val timeFormatEn = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
    private val dateFormatEn = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)

    fun formatDateTime(timestamp: Long, isArabic: Boolean): Pair<String, String> {
        val date = Date(timestamp)
        return if (isArabic) {
            Pair(timeFormatAr.format(date), dateFormatAr.format(date))
        } else {
            Pair(timeFormatEn.format(date), dateFormatEn.format(date))
        }
    }

    /**
     * Inspects the user's message to learn new facts, item locations, or real-time events.
     * Prevents storing sensitive credentials like passwords, API keys, or tokens.
     */
    suspend fun learnFromUserMessage(text: String, isArabic: Boolean, userId: String) {
        if (userId.isBlank()) return
        if (!isMemoryEnabled) return
        val trimmed = text.trim()

        // Privacy Guard: Do not save passwords, API keys, or tokens
        if (isSensitiveInformation(trimmed)) {
            return
        }

        val now = System.currentTimeMillis()
        val (formattedTime, formattedDate) = formatDateTime(now, isArabic)

        // 1. Name declaration: e.g. "اسمي عمر", "انا اسمي عمر", "my name is Omar"
        val nameRegexAr = Regex("^(?:أنا\\s+)?اسمي\\s+(?:هو\\s+)?([\\p{L}\\w]{2,20})", RegexOption.IGNORE_CASE)
        val nameRegexEn = Regex("^(?:i\\s+am|my\\s+name\\s+is)\\s+([a-zA-Z]{2,20})", RegexOption.IGNORE_CASE)
        
        nameRegexAr.find(trimmed)?.let { match ->
            val name = match.groupValues[1]
            saveOrUpdateMemory(userId, "user_name", name, "personal", now)
            return
        }
        nameRegexEn.find(trimmed)?.let { match ->
            val name = match.groupValues[1]
            saveOrUpdateMemory(userId, "user_name", name, "personal", now)
            return
        }

        // 2. Item Location: e.g. "حطيت الشاحن في الدرج", "وضعت المفتاح في الحقيبة", "I put the charger in the drawer"
        val locRegexAr = Regex("^(?:أنا\\s+)?(?:حطيت|وضعت|تركت)\\s+(.+?)\\s+في\\s+(.+)$", RegexOption.IGNORE_CASE)
        val locRegexEn = Regex("^(?:i\\s+put|i\\s+left)\\s+(?:the\\s+)?(.+?)\\s+in\\s+(?:the\\s+)?(.+)$", RegexOption.IGNORE_CASE)

        locRegexAr.find(trimmed)?.let { match ->
            val item = match.groupValues[1].trim()
            val location = match.groupValues[2].trim()
            saveOrUpdateMemory(userId, "location_$item", "$item في $location", "locations", now)
            return
        }
        locRegexEn.find(trimmed)?.let { match ->
            val item = match.groupValues[1].trim()
            val location = match.groupValues[2].trim()
            saveOrUpdateMemory(userId, "location_$item", "$item in $location", "locations", now)
            return
        }

        // 3. Event tracking with exact real timestamp:
        // e.g. "أنا خدت الدواء", "خدت الدواء", "أخذت علاجي", "شربت الدواء", "i took my medicine"
        val eventRegexAr = Regex("^(?:أنا\\s+)?(?:خدت|أخذت|شربت|صليت|أكلت|كلمت|عملت|دفعت)\\s+(.+)$", RegexOption.IGNORE_CASE)
        val eventRegexEn = Regex("^(?:i\\s+took|i\\s+drank|i\\s+prayed|i\\s+ate|i\\s+called|i\\s+paid)\\s+(?:my\\s+)?(.+)$", RegexOption.IGNORE_CASE)

        eventRegexAr.find(trimmed)?.let { match ->
            val eventDetails = match.groupValues[1].trim()
            val fullContent = "أخذت/فعلت $eventDetails في الساعة $formattedTime ($formattedDate)"
            saveOrUpdateMemory(userId, "event_$eventDetails", fullContent, "events", now)
            return
        }
        eventRegexEn.find(trimmed)?.let { match ->
            val eventDetails = match.groupValues[1].trim()
            val fullContent = "Took/did $eventDetails at $formattedTime ($formattedDate)"
            saveOrUpdateMemory(userId, "event_$eventDetails", fullContent, "events", now)
            return
        }
    }

    private suspend fun saveOrUpdateMemory(userId: String, key: String, content: String, category: String, timestamp: Long) {
        if (userId.isBlank()) return
        val existing = dao.getMemoryByKey(userId, key)
        if (existing != null) {
            dao.updateMemory(existing.copy(content = content, category = category, timestamp = timestamp))
        } else {
            dao.insertMemory(MemoryEntity(userId = userId, key = key, content = content, category = category, timestamp = timestamp))
        }
    }

    /**
     * Checks if the user's question directly seeks a memorized fact/event.
     * Returns the exact, non-hallucinated answer if matched, or null to delegate to Gemini.
     */
    suspend fun resolveDirectMemoryQuery(text: String, isArabic: Boolean, userId: String): String? {
        if (userId.isBlank()) return null
        if (!isMemoryEnabled) return null
        val clean = text.trim().removeSuffix("?").removeSuffix("؟").trim()

        // A. Name Query: "ما اسمي", "اسمك إيه", "ما هو اسمي", "what is my name"
        if (clean.matches(Regex("^(?:ما\\s+هو\\s+اسمي|ما\\s+اسمي|اسمي\\s+ايه|اسمي\\s+إيه|مين\\s+انا|what\\s+is\\s+my\\s+name)$", RegexOption.IGNORE_CASE))) {
            val nameMem = dao.getMemoryByKey(userId, "user_name")
            return if (nameMem != null) {
                if (isArabic) "اسمك ${nameMem.content}." else "Your name is ${nameMem.content}."
            } else {
                if (isArabic) "لم تخبرني باسمك بعد! ما هو اسمك؟" else "You haven't told me your name yet! What's your name?"
            }
        }

        // B. Location Query: "فين الشاحن", "أين الشاحن", "where is the charger"
        val locQueryAr = Regex("^(?:فين|أين)\\s+(?:ال)?(.+)$", RegexOption.IGNORE_CASE)
        val locQueryEn = Regex("^(?:where\\s+is|where's)\\s+(?:the\\s+)?(.+)$", RegexOption.IGNORE_CASE)

        locQueryAr.find(clean)?.let { match ->
            val item = match.groupValues[1].trim()
            val matches = dao.getMemoriesList(userId).filter { it.content.contains(item, true) || it.key.contains(item, true) }.filter { it.category == "locations" || it.key.startsWith("location_") }
            if (matches.isNotEmpty()) {
                val found = matches.first()
                return if (isArabic) "آخر مرة قلت لي إنك حطيت ${found.content}." else "Last time you told me you put ${found.content}."
            } else {
                return if (isArabic) "ليس لدي معلومة مسجلة عن مكان $item." else "I don't have a record of where $item is."
            }
        }
        locQueryEn.find(clean)?.let { match ->
            val item = match.groupValues[1].trim()
            val matches = dao.getMemoriesList(userId).filter { it.content.contains(item, true) || it.key.contains(item, true) }.filter { it.category == "locations" || it.key.startsWith("location_") }
            if (matches.isNotEmpty()) {
                val found = matches.first()
                return "Last time you told me: ${found.content}."
            } else {
                return "I don't have a record of where $item is."
            }
        }

        // C. Event confirmation: "أنا خدت الدواء؟", "هل أخذت الدواء؟", "did i take the medicine?"
        val eventQueryAr = Regex("^(?:هل\\s+)?(?:أنا\\s+)?(?:خدت|أخذت|شربت|صليت|عملت)\\s+(?:ال)?(.+)$", RegexOption.IGNORE_CASE)
        val whenQueryAr = Regex("^(?:إمتى|امتى|متى)\\s+(?:أنا\\s+)?(?:خدت|أخذت|شربت|صليت)\\s+(?:ال)?(.+)$", RegexOption.IGNORE_CASE)

        whenQueryAr.find(clean)?.let { match ->
            val item = match.groupValues[1].trim()
            val matches = dao.getMemoriesList(userId).filter { it.content.contains(item, true) || it.key.contains(item, true) }.filter { it.category == "events" || it.key.startsWith("event_") }
            if (matches.isNotEmpty()) {
                val ev = matches.first()
                val (t, d) = formatDateTime(ev.timestamp, isArabic)
                return if (isArabic) "أنت أخذت $item الساعة $t (بتاريخ $d)." else "You took $item at $t ($d)."
            } else {
                return if (isArabic) "ليس لدي معلومة مسجلة عن وقت أخذك لـ $item." else "I don't have a record for when you took $item."
            }
        }

        eventQueryAr.find(clean)?.let { match ->
            val item = match.groupValues[1].trim()
            val matches = dao.getMemoriesList(userId).filter { it.content.contains(item, true) || it.key.contains(item, true) }.filter { it.category == "events" || it.key.startsWith("event_") }
            if (matches.isNotEmpty()) {
                val ev = matches.first()
                val (t, _) = formatDateTime(ev.timestamp, isArabic)
                return if (isArabic) "أيوه، أنت قلت لي إنك أخذت $item الساعة $t." else "Yes, you told me you took $item at $t."
            } else {
                return if (isArabic) "ليس لدي معلومة مسجلة عن ذلك حتى الآن." else "I don't have a record of that yet."
            }
        }

        return null
    }

    private fun isSensitiveInformation(text: String): Boolean {
        val sensitivePatterns = listOf(
            "password", "كلمة المرور", "باسورد", "api_key", "secret", "token", "cvv", "credit card"
        )
        val lower = text.lowercase(Locale.ROOT)
        return sensitivePatterns.any { lower.contains(it) }
    }
}

package com.omar.ai.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omar.ai.data.voice.VoiceState
import com.omar.ai.ui.OmarStrings
import com.omar.ai.ui.theme.CyanAccent
import com.omar.ai.ui.theme.ElectricBlue
import com.omar.ai.ui.theme.EmeraldSuccess
import com.omar.ai.ui.theme.SoftIndigo

@Composable
fun VoiceOverlay(
    isArabic: Boolean,
    voiceState: VoiceState,
    liveSpokenText: String,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onStopSpeaking: () -> Unit,
    onClose: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_orb")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rotateAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotate"
    )

    val (orbColors, statusTitle, statusSubtitle) = when (voiceState) {
        VoiceState.LISTENING -> Triple(
            listOf(CyanAccent, ElectricBlue),
            OmarStrings.listening(isArabic),
            OmarStrings.tapToStop(isArabic)
        )
        VoiceState.THINKING -> Triple(
            listOf(SoftIndigo, ElectricBlue),
            OmarStrings.thinking(isArabic),
            "..."
        )
        VoiceState.SPEAKING -> Triple(
            listOf(EmeraldSuccess, CyanAccent),
            OmarStrings.speaking(isArabic),
            OmarStrings.tapToStop(isArabic)
        )
        VoiceState.IDLE -> Triple(
            listOf(ElectricBlue, SoftIndigo),
            OmarStrings.voiceChat(isArabic),
            OmarStrings.tapToSpeak(isArabic)
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.Black.copy(alpha = 0.88f)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Close Button Top End
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp)
                    .size(44.dp)
                    .background(Color.White.copy(alpha = 0.1f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close voice chat",
                    tint = Color.White
                )
            }

            // Center Orb & Status
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Interactive Voice Orb
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .scale(if (voiceState == VoiceState.LISTENING || voiceState == VoiceState.SPEAKING) pulseScale else 1f)
                        .clip(CircleShape)
                        .background(Brush.sweepGradient(orbColors))
                        .border(2.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                        .clickable {
                            when (voiceState) {
                                VoiceState.LISTENING -> onStopListening()
                                VoiceState.SPEAKING -> onStopSpeaking()
                                VoiceState.IDLE -> onStartListening()
                                VoiceState.THINKING -> {}
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (voiceState) {
                            VoiceState.LISTENING -> Icons.Default.Mic
                            VoiceState.SPEAKING -> Icons.Default.VolumeUp
                            VoiceState.THINKING -> Icons.Default.Mic
                            VoiceState.IDLE -> Icons.Default.Mic
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(56.dp)
                    )
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Status Label
                Text(
                    text = statusTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = statusSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Live Spoken Transcription
                AnimatedVisibility(
                    visible = liveSpokenText.isNotBlank(),
                    enter = fadeIn() + scaleIn(),
                    exit = fadeOut() + scaleOut()
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.12f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                    ) {
                        Text(
                            text = liveSpokenText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color(0xFFBAE6FD),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }

            // Bottom controls
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 48.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (voiceState == VoiceState.SPEAKING) {
                    IconButton(
                        onClick = onStopSpeaking,
                        modifier = Modifier
                            .size(54.dp)
                            .background(Color.Red.copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop speaking",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                } else if (voiceState == VoiceState.IDLE) {
                    IconButton(
                        onClick = onStartListening,
                        modifier = Modifier
                            .size(54.dp)
                            .background(CyanAccent, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Start listening",
                            tint = Color.Black,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }
    }
}

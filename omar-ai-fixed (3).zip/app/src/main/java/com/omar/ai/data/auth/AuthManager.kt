package com.omar.ai.data.auth

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import com.omar.ai.data.local.OmarDao
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import android.app.Activity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

data class UserProfile(
    val uid: String,
    val displayName: String,
    val email: String,
    val photoUrl: String? = null,
    val isGuest: Boolean = false,
    val isOnboarded: Boolean = false
)

class AuthManager(
    private val context: Context,
    private val omarDao: OmarDao
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("omar_ai_auth_prefs", Context.MODE_PRIVATE)

    private val credentialManager = CredentialManager.create(context)
    private var firebaseAuth: FirebaseAuth? = null

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _authErrorMessage = MutableStateFlow<String?>(null)
    val authErrorMessage: StateFlow<String?> = _authErrorMessage.asStateFlow()

    private var storedVerificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null

    private val _phoneCodeSent = MutableStateFlow(false)
    val phoneCodeSent: StateFlow<Boolean> = _phoneCodeSent.asStateFlow()

    private val _phoneNumberInProgress = MutableStateFlow<String?>(null)
    val phoneNumberInProgress: StateFlow<String?> = _phoneNumberInProgress.asStateFlow()

    private val credentialsPrefs: SharedPreferences =
        context.getSharedPreferences("omar_ai_credentials_store", Context.MODE_PRIVATE)

    init {
        try {
            firebaseAuth = FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.w("AuthManager", "FirebaseAuth not initialized, local fallback active", e)
        }
        loadPersistedSession()
    }

    private fun loadPersistedSession() {
        val fbUser = firebaseAuth?.currentUser
        if (fbUser != null) {
            _currentUser.value = UserProfile(
                uid = fbUser.uid,
                displayName = fbUser.displayName ?: "مستخدم Omar AI",
                email = fbUser.email ?: "",
                photoUrl = fbUser.photoUrl?.toString(),
                isGuest = false,
                isOnboarded = prefs.getBoolean("is_onboarded", true)
            )
            return
        }

        val uid = prefs.getString("user_uid", null)
        if (uid != null) {
            val isGuest = prefs.getBoolean("is_guest", true)
            val name = prefs.getString("user_name", if (isGuest) "ضيف Omar AI" else "المستخدم") ?: "مستخدم Omar AI"
            val email = prefs.getString("user_email", "") ?: ""
            val photo = prefs.getString("user_photo", null)
            val onboarded = prefs.getBoolean("is_onboarded", true)
            _currentUser.value = UserProfile(
                uid = uid,
                displayName = name,
                email = email,
                photoUrl = photo,
                isGuest = isGuest,
                isOnboarded = onboarded
            )
        }
    }

    fun markOnboarded() {
        prefs.edit().putBoolean("is_onboarded", true).apply()
        _currentUser.value = _currentUser.value?.copy(isOnboarded = true)
    }

    fun continueAsGuest(): UserProfile {
        val guestUid = "guest_" + System.currentTimeMillis().toString().takeLast(8)
        val guestProfile = UserProfile(
            uid = guestUid,
            displayName = "ضيف Omar AI",
            email = "guest@omar.ai",
            photoUrl = null,
            isGuest = true,
            isOnboarded = true
        )
        persistUser(guestProfile)
        _currentUser.value = guestProfile
        return guestProfile
    }

    suspend fun signInWithGoogleCredential(activityContext: Context): Result<UserProfile> = withContext(Dispatchers.Main) {
        _isAuthLoading.value = true
        _authErrorMessage.value = null
        try {
            // Web client ID (client_type 3) from google-services.json – required for ID token
            val webClientId = "965219204308-0ijuu9c40k79p78hs9f6c08rss4rltja.apps.googleusercontent.com"

            val nonce = java.util.UUID.randomUUID().toString().replace("-", "")

            // Option A: Google ID (bottom-sheet account picker)
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .setAutoSelectEnabled(false)
                .setNonce(nonce)
                .build()

            // Option B: Sign-In-With-Google button style (more reliable on some devices)
            val signInWithGoogleOption = GetSignInWithGoogleOption.Builder(webClientId)
                .setNonce(nonce)
                .build()

            var response: GetCredentialResponse
            try {
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()
                response = credentialManager.getCredential(
                    context = activityContext,
                    request = request
                )
            } catch (first: Exception) {
                Log.w("AuthManager", "GetGoogleIdOption failed, trying SignInWithGoogle", first)
                // Retry with Sign-In-With-Google option
                val request2 = GetCredentialRequest.Builder()
                    .addCredentialOption(signInWithGoogleOption)
                    .build()
                response = credentialManager.getCredential(
                    context = activityContext,
                    request = request2
                )
            }

            val credential = response.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleCred.idToken
                if (idToken.isNullOrBlank()) {
                    _isAuthLoading.value = false
                    val err = "لم يتم استلام رمز Google. تحقق من SHA-1 و Web Client ID في Firebase."
                    _authErrorMessage.value = err
                    return@withContext Result.failure(Exception(err))
                }

                val displayName = googleCred.displayName ?: "مستخدم Google"
                val email = googleCred.id
                val profilePic = googleCred.profilePictureUri?.toString()

                // Prefer real Firebase UID (required for Firestore sync + Phone/Google linking)
                val finalUid = withContext(Dispatchers.IO) {
                    try {
                        val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                        val authResult = firebaseAuth?.signInWithCredential(authCredential)?.await()
                        authResult?.user?.uid
                    } catch (e: Exception) {
                        Log.e("AuthManager", "Firebase Google credential failed", e)
                        null
                    }
                }

                if (finalUid.isNullOrBlank()) {
                    _isAuthLoading.value = false
                    val err = "فشل ربط حساب Google مع Firebase. فعّل مزوّد Google في Authentication وتأكد من SHA-1."
                    _authErrorMessage.value = err
                    return@withContext Result.failure(Exception(err))
                }

                val user = UserProfile(
                    uid = finalUid,
                    displayName = displayName,
                    email = email,
                    photoUrl = profilePic,
                    isGuest = false,
                    isOnboarded = true
                )
                persistUser(user)
                _currentUser.value = user
                _isAuthLoading.value = false
                Result.success(user)
            } else {
                _isAuthLoading.value = false
                val err = "نوع اعتماد Google غير مدعوم على هذا الجهاز"
                _authErrorMessage.value = err
                Result.failure(Exception(err))
            }
        } catch (e: androidx.credentials.exceptions.GetCredentialCancellationException) {
            _isAuthLoading.value = false
            // User cancelled – not a fatal error
            Log.i("AuthManager", "Google Sign-In cancelled by user")
            Result.failure(Exception("تم إلغاء تسجيل الدخول"))
        } catch (e: androidx.credentials.exceptions.NoCredentialException) {
            _isAuthLoading.value = false
            val err = "لا يوجد حساب Google على الجهاز أو تم رفض الوصول"
            _authErrorMessage.value = err
            Log.e("AuthManager", "NoCredentialException", e)
            Result.failure(Exception(err))
        } catch (e: Exception) {
            _isAuthLoading.value = false
            val err = e.localizedMessage ?: "فشل تسجيل الدخول بحساب Google"
            _authErrorMessage.value = err
            Log.e("AuthManager", "Google Sign-In failed", e)
            Result.failure(e)
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        _isAuthLoading.value = true
        _authErrorMessage.value = null
        val cleanEmail = email.trim().lowercase()
        try {
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
                val err = "يرجى إدخال بريد إلكتروني صحيح"
                _authErrorMessage.value = err
                _isAuthLoading.value = false
                return@withContext Result.failure(Exception(err))
            }
            if (pass.length < 6) {
                val err = "كلمة المرور يجب ألا تقل عن 6 أحرف"
                _authErrorMessage.value = err
                _isAuthLoading.value = false
                return@withContext Result.failure(Exception(err))
            }

            // Try Firebase Auth if available
            try {
                val fbResult = firebaseAuth?.signInWithEmailAndPassword(cleanEmail, pass)?.await()
                if (fbResult?.user != null) {
                    val u = fbResult.user!!
                    val profile = UserProfile(
                        uid = u.uid,
                        displayName = u.displayName ?: cleanEmail.substringBefore("@"),
                        email = u.email ?: cleanEmail,
                        isGuest = false,
                        isOnboarded = true
                    )
                    persistUser(profile)
                    _currentUser.value = profile
                    _isAuthLoading.value = false
                    return@withContext Result.success(profile)
                }
            } catch (e: Exception) {
                Log.w("AuthManager", "Firebase email sign-in exception, checking local credential store", e)
            }

            // Check local secure credential store
            val storedHash = credentialsPrefs.getString("hash_$cleanEmail", null)
            val storedSalt = credentialsPrefs.getString("salt_$cleanEmail", null)
            val storedName = credentialsPrefs.getString("name_$cleanEmail", cleanEmail.substringBefore("@")) ?: "المستخدم"

            if (storedHash != null && storedSalt != null) {
                val testHash = hashPassword(pass, storedSalt)
                if (testHash == storedHash) {
                    val profile = UserProfile(
                        uid = "usr_" + cleanEmail.hashCode().toString().takeLast(8),
                        displayName = storedName,
                        email = cleanEmail,
                        isGuest = false,
                        isOnboarded = true
                    )
                    persistUser(profile)
                    _currentUser.value = profile
                    _isAuthLoading.value = false
                    return@withContext Result.success(profile)
                } else {
                    val err = "كلمة المرور غير صحيحة"
                    _authErrorMessage.value = err
                    _isAuthLoading.value = false
                    return@withContext Result.failure(Exception(err))
                }
            } else {
                val err = "الحساب غير مسجل، يرجى إنشاء حساب جديد أولاً"
                _authErrorMessage.value = err
                _isAuthLoading.value = false
                return@withContext Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            val err = e.localizedMessage ?: "حدث خطأ أثناء تسجيل الدخول"
            _authErrorMessage.value = err
            _isAuthLoading.value = false
            Result.failure(e)
        }
    }

    suspend fun signUpWithEmail(name: String, email: String, pass: String, confirmPass: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        _isAuthLoading.value = true
        _authErrorMessage.value = null
        val cleanEmail = email.trim().lowercase()
        val cleanName = name.trim().ifBlank { cleanEmail.substringBefore("@") }
        try {
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
                val err = "يرجى إدخال بريد إلكتروني صالح"
                _authErrorMessage.value = err
                _isAuthLoading.value = false
                return@withContext Result.failure(Exception(err))
            }
            if (pass.length < 6) {
                val err = "كلمة المرور يجب ألا تقل عن 6 خانات"
                _authErrorMessage.value = err
                _isAuthLoading.value = false
                return@withContext Result.failure(Exception(err))
            }
            if (pass != confirmPass) {
                val err = "كلمتا المرور غير متطابقتين"
                _authErrorMessage.value = err
                _isAuthLoading.value = false
                return@withContext Result.failure(Exception(err))
            }

            // Attempt Firebase user creation
            try {
                val fbResult = firebaseAuth?.createUserWithEmailAndPassword(cleanEmail, pass)?.await()
                if (fbResult?.user != null) {
                    val u = fbResult.user!!
                    val profile = UserProfile(
                        uid = u.uid,
                        displayName = cleanName,
                        email = cleanEmail,
                        isGuest = false,
                        isOnboarded = true
                    )
                    persistUser(profile)
                    _currentUser.value = profile
                    _isAuthLoading.value = false
                    return@withContext Result.success(profile)
                }
            } catch (e: Exception) {
                Log.w("AuthManager", "Firebase user creation skipped or offline, using local secure store", e)
            }

            // Store securely locally
            val salt = java.util.UUID.randomUUID().toString().take(8)
            val hash = hashPassword(pass, salt)
            credentialsPrefs.edit()
                .putString("hash_$cleanEmail", hash)
                .putString("salt_$cleanEmail", salt)
                .putString("name_$cleanEmail", cleanName)
                .apply()

            val profile = UserProfile(
                uid = "usr_" + cleanEmail.hashCode().toString().takeLast(8),
                displayName = cleanName,
                email = cleanEmail,
                isGuest = false,
                isOnboarded = true
            )
            persistUser(profile)
            _currentUser.value = profile
            _isAuthLoading.value = false
            Result.success(profile)
        } catch (e: Exception) {
            val err = e.localizedMessage ?: "فشل إنشاء الحساب"
            _authErrorMessage.value = err
            _isAuthLoading.value = false
            Result.failure(e)
        }
    }

    suspend fun sendPasswordReset(email: String): Result<String> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            return@withContext Result.failure(Exception("يرجى إدخال بريد إلكتروني صحيح"))
        }
        try {
            firebaseAuth?.sendPasswordResetEmail(cleanEmail)?.await()
        } catch (e: Exception) {
            Log.w("AuthManager", "Firebase reset email notice", e)
        }
        Result.success("تم إرسال رابط إعادة تعيين كلمة المرور إلى: $cleanEmail")
    }

    fun clearAuthError() {
        _authErrorMessage.value = null
    }

    private fun hashPassword(password: String, salt: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val bytes = md.digest((salt + password).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }


    /**
     * Start phone verification. [phoneE164] must be E.164 format, e.g. +201234567890
     * Requires a real Activity for reCAPTCHA / Play Integrity.
     */
    suspend fun startPhoneVerification(activity: Activity, phoneE164: String): Result<Unit> =
        withContext(Dispatchers.Main) {
            _isAuthLoading.value = true
            _authErrorMessage.value = null
            _phoneCodeSent.value = false
            val normalized = phoneE164.trim().replace(" ", "")
            if (!normalized.startsWith("+") || normalized.length < 10) {
                _isAuthLoading.value = false
                val msg = "أدخل الرقم بصيغة دولية مثل +201234567890"
                _authErrorMessage.value = msg
                return@withContext Result.failure(IllegalArgumentException(msg))
            }
            val auth = firebaseAuth
            if (auth == null) {
                _isAuthLoading.value = false
                val msg = "Firebase Auth غير مهيأ"
                _authErrorMessage.value = msg
                return@withContext Result.failure(IllegalStateException(msg))
            }

            try {
                suspendCancellableCoroutine<Unit> { cont ->
                    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                            // Auto-retrieval / instant verification
                            try {
                                // Run blocking sign-in on background is heavy; fire-and-forget via coroutine scope of caller is hard here.
                                // Store and complete via verify path by signing in directly:
                                kotlinx.coroutines.runBlocking(Dispatchers.IO) {
                                    finishPhoneSignIn(credential, normalized)
                                }
                            } catch (e: Exception) {
                                _authErrorMessage.value = e.message
                                Log.e("AuthManager", "auto phone sign-in failed", e)
                            }
                            _isAuthLoading.value = false
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onVerificationFailed(e: FirebaseException) {
                            _isAuthLoading.value = false
                            val msg = e.localizedMessage ?: "فشل التحقق من الرقم"
                            _authErrorMessage.value = msg
                            Log.e("AuthManager", "Phone verification failed", e)
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onCodeSent(
                            verificationId: String,
                            token: PhoneAuthProvider.ForceResendingToken
                        ) {
                            storedVerificationId = verificationId
                            resendToken = token
                            _phoneNumberInProgress.value = normalized
                            _phoneCodeSent.value = true
                            _isAuthLoading.value = false
                            if (cont.isActive) cont.resume(Unit)
                        }
                    }

                    val optionsBuilder = PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(normalized)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(activity)
                        .setCallbacks(callbacks)
                    resendToken?.let { optionsBuilder.setForceResendingToken(it) }
                    PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
                }
                Result.success(Unit)
            } catch (e: Exception) {
                _isAuthLoading.value = false
                _authErrorMessage.value = e.message
                Result.failure(e)
            }
        }

    /** Verify the 6-digit SMS code and complete sign-in. */
    suspend fun verifyPhoneCode(smsCode: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        _isAuthLoading.value = true
        _authErrorMessage.value = null
        val verificationId = storedVerificationId
        if (verificationId.isNullOrBlank()) {
            _isAuthLoading.value = false
            val msg = "لم يتم إرسال رمز التحقق بعد. اطلب الرمز أولاً."
            _authErrorMessage.value = msg
            return@withContext Result.failure(IllegalStateException(msg))
        }
        val code = smsCode.trim()
        if (code.length < 4) {
            _isAuthLoading.value = false
            val msg = "أدخل رمز التحقق كاملاً"
            _authErrorMessage.value = msg
            return@withContext Result.failure(IllegalArgumentException(msg))
        }
        try {
            val credential = PhoneAuthProvider.getCredential(verificationId, code)
            val phone = _phoneNumberInProgress.value ?: ""
            val profile = finishPhoneSignIn(credential, phone)
            Result.success(profile)
        } catch (e: Exception) {
            Log.e("AuthManager", "verifyPhoneCode failed", e)
            _isAuthLoading.value = false
            val msg = e.localizedMessage ?: "رمز التحقق غير صحيح"
            _authErrorMessage.value = msg
            Result.failure(e)
        }
    }

    private suspend fun finishPhoneSignIn(credential: PhoneAuthCredential, phone: String): UserProfile {
        val auth = firebaseAuth ?: throw IllegalStateException("Firebase Auth unavailable")
        val result = auth.signInWithCredential(credential).await()
        val user = result.user ?: throw IllegalStateException("No Firebase user after phone sign-in")
        val profile = UserProfile(
            uid = user.uid,
            displayName = user.displayName ?: phone.ifBlank { "مستخدم الهاتف" },
            email = user.email ?: phone,
            photoUrl = user.photoUrl?.toString(),
            isGuest = false,
            isOnboarded = true
        )
        persistUser(profile)
        _currentUser.value = profile
        _isAuthLoading.value = false
        _phoneCodeSent.value = false
        storedVerificationId = null
        return profile
    }

    fun resetPhoneAuthState() {
        storedVerificationId = null
        resendToken = null
        _phoneCodeSent.value = false
        _phoneNumberInProgress.value = null
        _authErrorMessage.value = null
    }


    suspend fun signOut() = withContext(Dispatchers.IO) {
        try {
            firebaseAuth?.signOut()
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.w("AuthManager", "Sign out cleanup exception", e)
        }
        prefs.edit()
            .remove("user_uid")
            .remove("user_name")
            .remove("user_email")
            .remove("user_photo")
            .remove("is_guest")
            .apply()
        _currentUser.value = null
    }

    suspend fun deleteAccountAndData() = withContext(Dispatchers.IO) {
        val uid = _currentUser.value?.uid ?: prefs.getString("user_uid", "") ?: ""
        if (uid.isNotBlank()) {
            omarDao.clearAllConversations(uid)
            omarDao.clearAllMessages(uid)
            omarDao.clearAllMemories(uid)
            omarDao.clearAllTodos(uid)
        }
        signOut()
    }

    private fun persistUser(user: UserProfile) {
        prefs.edit()
            .putString("user_uid", user.uid)
            .putString("user_name", user.displayName)
            .putString("user_email", user.email)
            .putString("user_photo", user.photoUrl)
            .putBoolean("is_guest", user.isGuest)
            .putBoolean("is_onboarded", true)
            .apply()
    }
}

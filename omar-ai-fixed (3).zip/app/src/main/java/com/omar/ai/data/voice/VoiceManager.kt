package com.omar.ai.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

/**
 * Production voice engine with automatic Arabic / English detection
 * for both Speech-to-Text and Text-to-Speech (mixed-language friendly).
 */
class VoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    private val _voiceState = MutableStateFlow(VoiceState.IDLE)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _liveSpokenText = MutableStateFlow("")
    val liveSpokenText: StateFlow<String> = _liveSpokenText.asStateFlow()

    private val _detectedLanguage = MutableStateFlow("ar")
    val detectedLanguage: StateFlow<String> = _detectedLanguage.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            // Prefer Arabic, fall back to English, then device default
            val ar = tts?.setLanguage(Locale("ar"))
            if (ar == TextToSpeech.LANG_MISSING_DATA || ar == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w("VoiceManager", "Arabic TTS missing, trying en-US")
                val en = tts?.setLanguage(Locale.US)
                if (en == TextToSpeech.LANG_MISSING_DATA || en == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _voiceState.value = VoiceState.SPEAKING
                }
                override fun onDone(utteranceId: String?) {
                    _voiceState.value = VoiceState.IDLE
                }
                override fun onError(utteranceId: String?) {
                    _voiceState.value = VoiceState.IDLE
                }
            })
        } else {
            Log.e("VoiceManager", "TTS init failed: $status")
        }
    }

    /**
     * Start listening. Pass null/blank languageCode to auto-detect preferred language
     * based on app locale or previous detection (supports mixed Arabic/English).
     */
    fun startListening(
        languageCode: String? = null,
        onFinalResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("التعرف على الصوت غير متاح على هذا الجهاز. / Speech recognition unavailable.")
            return
        }

        stopSpeaking()
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val preferred = resolveSttLanguage(languageCode)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, preferred)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, preferred)
            // Allow mixed results – do NOT force only one language preference
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _voiceState.value = VoiceState.LISTENING
                _liveSpokenText.value = ""
            }

            override fun onBeginningOfSpeech() {
                _voiceState.value = VoiceState.LISTENING
            }

            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _voiceState.value = VoiceState.THINKING
            }

            override fun onError(error: Int) {
                _voiceState.value = VoiceState.IDLE
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH ->
                        "لم يتم التعرف على الصوت / No speech match"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "انتهت مهلة التحدث / Speech timeout"
                    SpeechRecognizer.ERROR_AUDIO ->
                        "خطأ في تسجيل الصوت / Audio error"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "خطأ في الشبكة / Network error"
                    SpeechRecognizer.ERROR_CLIENT ->
                        "خطأ في العميل / Client error – حاول مرة أخرى"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                        "المحرك مشغول / Recognizer busy"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "صلاحية الميكروفون مطلوبة / Microphone permission required"
                    else -> "خطأ في الاستماع ($error) / Listening error"
                }
                onError(msg)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull()?.trim().orEmpty()
                _liveSpokenText.value = spoken
                _voiceState.value = VoiceState.THINKING
                if (spoken.isNotBlank()) {
                    // Update detected language from the spoken text itself
                    _detectedLanguage.value = if (isMostlyArabic(spoken)) "ar" else "en"
                    onFinalResult(spoken)
                } else {
                    _voiceState.value = VoiceState.IDLE
                    onError("لم يُسمع أي كلام / No speech heard")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val partial = matches?.firstOrNull()?.trim().orEmpty()
                if (partial.isNotBlank()) {
                    _liveSpokenText.value = partial
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _voiceState.value = VoiceState.IDLE
            onError("فشل بدء الاستماع: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.w("VoiceManager", "stopListening", e)
        }
        if (_voiceState.value == VoiceState.LISTENING) {
            _voiceState.value = VoiceState.IDLE
        }
    }

    fun setThinkingState() {
        _voiceState.value = VoiceState.THINKING
    }

    /**
     * Speak text with automatic language selection.
     * Mixed Arabic/English text is split and spoken with the appropriate voice when possible.
     */
    fun speak(text: String, speed: Float = 1.0f) {
        if (!isTtsReady || text.isBlank()) return
        stopListening()
        stopSpeaking()

        val cleanText = sanitizeTextForTTS(text)
        if (cleanText.isBlank()) return

        tts?.setSpeechRate(speed.coerceIn(0.5f, 2.0f))
        _voiceState.value = VoiceState.SPEAKING

        // Prefer single-language pass for natural flow; switch locale by majority script
        val useArabic = isMostlyArabic(cleanText)
        val locale = if (useArabic) Locale("ar") else Locale.US
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback chain
            if (useArabic) {
                tts?.setLanguage(Locale.US)
            } else {
                tts?.setLanguage(Locale("ar"))
            }
        }

        val utteranceId = "utt_${System.currentTimeMillis()}"
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        if (tts?.isSpeaking == true) {
            tts?.stop()
        }
        if (_voiceState.value == VoiceState.SPEAKING) {
            _voiceState.value = VoiceState.IDLE
        }
    }

    fun isSpeaking(): Boolean = tts?.isSpeaking == true

    /** True if Arabic characters dominate the text (handles mixed language). */
    fun isMostlyArabic(text: String): Boolean {
        var ar = 0
        var latin = 0
        for (c in text) {
            when {
                c.isWhitespace() || c.isDigit() -> continue
                Character.UnicodeBlock.of(c) in ARABIC_BLOCKS -> ar++
                c in 'A'..'Z' || c in 'a'..'z' -> latin++
            }
        }
        return ar >= latin
    }

    private fun resolveSttLanguage(explicit: String?): String {
        if (!explicit.isNullOrBlank()) return explicit
        // Prefer last detected language; default Arabic for Omar AI
        return when (_detectedLanguage.value) {
            "en" -> "en-US"
            else -> "ar-SA"
        }
    }

    private fun sanitizeTextForTTS(input: String): String {
        return input
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("`[^`]+`"), " ")
            .replace(Regex("\\*\\*?|__?|~~|#+"), " ")
            .replace(Regex("https?://\\S+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        isTtsReady = false
    }

    companion object {
        private val ARABIC_BLOCKS = setOf(
            Character.UnicodeBlock.ARABIC,
            Character.UnicodeBlock.ARABIC_SUPPLEMENT,
            Character.UnicodeBlock.ARABIC_PRESENTATION_FORMS_A,
            Character.UnicodeBlock.ARABIC_PRESENTATION_FORMS_B,
            Character.UnicodeBlock.ARABIC_EXTENDED_A
        )
    }
}

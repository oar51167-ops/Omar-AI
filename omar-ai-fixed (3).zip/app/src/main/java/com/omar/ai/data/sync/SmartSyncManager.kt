package com.omar.ai.data.sync

import android.content.Context
import android.util.Log
import com.omar.ai.data.local.ChatMessageEntity
import com.omar.ai.data.local.ConversationEntity
import com.omar.ai.data.local.MemoryEntity
import com.omar.ai.data.local.OmarDao
import com.omar.ai.data.local.TodoEntity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Smart cloud sync for Omar AI.
 *
 * - Local Room remains the source of truth for offline use.
 * - Firestore mirrors data under users/{uid}/...
 * - Push is debounced (smart batching).
 * - Pull on sign-in merges cloud → local without wiping newer local rows.
 * - Guests are never synced.
 *
 * Required Firebase Console setup:
 * 1. Enable Cloud Firestore
 * 2. Rules that restrict each user to users/{uid}/**
 */
class SmartSyncManager(
    private val context: Context,
    private val dao: OmarDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    private val _syncState = MutableStateFlow(SyncState.IDLE)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _lastSyncMessage = MutableStateFlow<String?>(null)
    val lastSyncMessage: StateFlow<String?> = _lastSyncMessage.asStateFlow()

    private var debounceJob: Job? = null
    private var enabled: Boolean = true

    enum class SyncState {
        IDLE,
        SYNCING,
        SUCCESS,
        ERROR,
        DISABLED
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        context.getSharedPreferences("omar_ai_sync", Context.MODE_PRIVATE)
            .edit().putBoolean("smart_sync_enabled", value).apply()
        if (!value) _syncState.value = SyncState.DISABLED
    }

    fun isEnabled(): Boolean {
        return context.getSharedPreferences("omar_ai_sync", Context.MODE_PRIVATE)
            .getBoolean("smart_sync_enabled", true).also { enabled = it }
    }

    private fun uidOrNull(): String? {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank()) return null
        // Do not sync pure guests
        if (uid.startsWith("guest_")) return null
        return uid
    }

    /** Call after successful Google / Email login. */
    fun pullOnLogin(userId: String) {
        if (!isEnabled()) return
        if (userId.isBlank() || userId.startsWith("guest_")) return
        scope.launch {
            try {
                _syncState.value = SyncState.SYNCING
                pullAll(userId)
                _syncState.value = SyncState.SUCCESS
                _lastSyncMessage.value = "تمت المزامنة من السحابة"
            } catch (e: Exception) {
                Log.e(TAG, "pullOnLogin failed", e)
                _syncState.value = SyncState.ERROR
                _lastSyncMessage.value = e.message ?: "فشل السحب من السحابة"
            }
        }
    }

    /** Schedule a smart (debounced) full push for the current user. */
    fun schedulePush(userId: String? = null) {
        if (!isEnabled()) return
        val uid = userId ?: uidOrNull() ?: return
        debounceJob?.cancel()
        debounceJob = scope.launch {
            delay(DEBOUNCE_MS)
            try {
                _syncState.value = SyncState.SYNCING
                pushAll(uid)
                _syncState.value = SyncState.SUCCESS
                _lastSyncMessage.value = "تمت المزامنة إلى السحابة"
            } catch (e: Exception) {
                Log.e(TAG, "schedulePush failed", e)
                _syncState.value = SyncState.ERROR
                _lastSyncMessage.value = e.message ?: "فشل الرفع إلى السحابة"
            }
        }
    }

    /** Immediate push of a single conversation + its messages. */
    fun pushConversationNow(userId: String, conversation: ConversationEntity, messages: List<ChatMessageEntity>) {
        if (!isEnabled()) return
        if (userId.isBlank() || userId.startsWith("guest_")) return
        if (conversation.isTemporary) return
        scope.launch {
            try {
                val convRef = db.collection("users").document(userId)
                    .collection("conversations").document(conversation.id)
                convRef.set(conversationToMap(conversation), SetOptions.merge()).await()

                val batch = db.batch()
                val msgCol = convRef.collection("messages")
                for (msg in messages) {
                    // Skip huge base64 to keep Firestore under size limits
                    batch.set(msgCol.document(msg.id), messageToMap(msg), SetOptions.merge())
                }
                batch.commit().await()
            } catch (e: Exception) {
                Log.w(TAG, "pushConversationNow failed", e)
            }
        }
    }

    fun pushMemoryNow(userId: String, memory: MemoryEntity) {
        if (!isEnabled()) return
        if (userId.isBlank() || userId.startsWith("guest_")) return
        scope.launch {
            try {
                val id = if (memory.id > 0) memory.id.toString() else memory.key
                db.collection("users").document(userId)
                    .collection("memories").document(id)
                    .set(memoryToMap(memory), SetOptions.merge()).await()
            } catch (e: Exception) {
                Log.w(TAG, "pushMemoryNow failed", e)
            }
        }
    }

    fun deleteConversationRemote(userId: String, conversationId: String) {
        if (!isEnabled()) return
        if (userId.isBlank() || userId.startsWith("guest_")) return
        scope.launch {
            try {
                val convRef = db.collection("users").document(userId)
                    .collection("conversations").document(conversationId)
                // Delete messages subcollection in pages
                val msgs = convRef.collection("messages").get().await()
                val batch = db.batch()
                for (doc in msgs.documents) batch.delete(doc.reference)
                batch.delete(convRef)
                batch.commit().await()
            } catch (e: Exception) {
                Log.w(TAG, "deleteConversationRemote failed", e)
            }
        }
    }

    fun deleteMemoryRemote(userId: String, memoryId: Long, key: String) {
        if (!isEnabled()) return
        if (userId.isBlank() || userId.startsWith("guest_")) return
        scope.launch {
            try {
                val col = db.collection("users").document(userId).collection("memories")
                col.document(memoryId.toString()).delete().await()
                col.document(key).delete().await()
            } catch (e: Exception) {
                Log.w(TAG, "deleteMemoryRemote failed", e)
            }
        }
    }

    // ---------- Internal ----------

    private suspend fun pullAll(userId: String) = withContext(Dispatchers.IO) {
        // Conversations
        val convSnap = db.collection("users").document(userId)
            .collection("conversations").get().await()
        for (doc in convSnap.documents) {
            val remote = mapToConversation(doc.id, doc.data ?: continue, userId) ?: continue
            val local = dao.getConversationById(remote.id, userId)
            if (local == null || remote.updatedAt >= local.updatedAt) {
                dao.insertConversation(remote)
            }
            // Messages for this conversation
            val msgSnap = doc.reference.collection("messages").get().await()
            for (m in msgSnap.documents) {
                val msg = mapToMessage(m.id, m.data ?: continue, userId, remote.id) ?: continue
                dao.insertMessage(msg)
            }
        }

        // Memories
        val memSnap = db.collection("users").document(userId)
            .collection("memories").get().await()
        for (doc in memSnap.documents) {
            val mem = mapToMemory(doc.data ?: continue, userId) ?: continue
            val existing = dao.getMemoryByKey(userId, mem.key)
            if (existing == null) {
                dao.insertMemory(mem.copy(id = 0))
            } else if (mem.timestamp >= existing.timestamp) {
                dao.updateMemory(existing.copy(content = mem.content, category = mem.category, timestamp = mem.timestamp))
            }
        }

        // Todos
        val todoSnap = db.collection("users").document(userId)
            .collection("todos").get().await()
        for (doc in todoSnap.documents) {
            val todo = mapToTodo(doc.data ?: continue, userId) ?: continue
            dao.insertTodo(todo.copy(id = 0))
        }
    }

    private suspend fun pushAll(userId: String) = withContext(Dispatchers.IO) {
        pushConversationsFromLocal(userId)
        pushMemoriesFromLocal(userId)
    }

    private suspend fun pushConversationsFromLocal(userId: String) {
        val conversations = dao.getAllUserConversationsList(userId)
        for (c in conversations) {
            if (c.isTemporary) continue
            val convRef = db.collection("users").document(userId)
                .collection("conversations").document(c.id)
            convRef.set(conversationToMap(c), SetOptions.merge()).await()
            val messages = dao.getMessagesListForConversation(c.id)
            if (messages.isEmpty()) continue
            // Batch in chunks of 400
            messages.chunked(400).forEach { chunk ->
                val batch = db.batch()
                val msgCol = convRef.collection("messages")
                for (msg in chunk) {
                    batch.set(msgCol.document(msg.id), messageToMap(msg), SetOptions.merge())
                }
                batch.commit().await()
            }
        }
    }

    private suspend fun pushMemoriesFromLocal(userId: String) {
        val list = dao.getMemoriesList(userId)
        for (mem in list) {
            val id = if (mem.id > 0) mem.id.toString() else mem.key
            db.collection("users").document(userId)
                .collection("memories").document(id)
                .set(memoryToMap(mem), SetOptions.merge()).await()
        }
    }

    private suspend fun pushTodosFromLocal(userId: String) {
        // Todos only available as Flow; skip full dump – incremental from UI is enough.
    }

    // ---------- Mappers ----------

    private fun conversationToMap(c: ConversationEntity): Map<String, Any?> = mapOf(
        "id" to c.id,
        "userId" to c.userId,
        "title" to c.title,
        "createdAt" to c.createdAt,
        "updatedAt" to c.updatedAt,
        "isPinned" to c.isPinned,
        "isTemporary" to c.isTemporary,
        "isArchived" to c.isArchived,
        "mode" to c.mode
    )

    private fun messageToMap(m: ChatMessageEntity): Map<String, Any?> = mapOf(
        "id" to m.id,
        "conversationId" to m.conversationId,
        "userId" to m.userId,
        "role" to m.role,
        "content" to m.content,
        "timestamp" to m.timestamp,
        // Intentionally omit large imageBase64 to stay under Firestore 1MB doc limit
        "imageUri" to m.imageUri,
        "actionType" to m.actionType,
        "actionParamsJson" to m.actionParamsJson,
        "suggestionsJson" to m.suggestionsJson,
        "videoUri" to m.videoUri,
        "mediaType" to m.mediaType,
        "fileName" to m.fileName,
        "status" to m.status
    )

    private fun memoryToMap(m: MemoryEntity): Map<String, Any?> = mapOf(
        "id" to m.id,
        "userId" to m.userId,
        "key" to m.key,
        "content" to m.content,
        "category" to m.category,
        "timestamp" to m.timestamp,
        "createdAt" to m.createdAt
    )

    private fun mapToConversation(id: String, data: Map<String, Any?>, userId: String): ConversationEntity? {
        return try {
            ConversationEntity(
                id = id,
                userId = (data["userId"] as? String) ?: userId,
                title = data["title"] as? String ?: "محادثة",
                createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (data["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                isPinned = data["isPinned"] as? Boolean ?: false,
                isTemporary = data["isTemporary"] as? Boolean ?: false,
                isArchived = data["isArchived"] as? Boolean ?: false,
                mode = data["mode"] as? String ?: "GENERAL"
            )
        } catch (e: Exception) {
            Log.w(TAG, "mapToConversation", e)
            null
        }
    }

    private fun mapToMessage(id: String, data: Map<String, Any?>, userId: String, convId: String): ChatMessageEntity? {
        return try {
            ChatMessageEntity(
                id = id,
                conversationId = data["conversationId"] as? String ?: convId,
                userId = (data["userId"] as? String) ?: userId,
                role = data["role"] as? String ?: "USER",
                content = data["content"] as? String ?: "",
                timestamp = (data["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                imageUri = data["imageUri"] as? String,
                actionType = data["actionType"] as? String,
                actionParamsJson = data["actionParamsJson"] as? String,
                suggestionsJson = data["suggestionsJson"] as? String,
                videoUri = data["videoUri"] as? String,
                mediaType = data["mediaType"] as? String,
                fileName = data["fileName"] as? String,
                status = data["status"] as? String ?: "SUCCESS"
            )
        } catch (e: Exception) {
            Log.w(TAG, "mapToMessage", e)
            null
        }
    }

    private fun mapToMemory(data: Map<String, Any?>, userId: String): MemoryEntity? {
        return try {
            MemoryEntity(
                id = (data["id"] as? Number)?.toLong() ?: 0L,
                userId = (data["userId"] as? String) ?: userId,
                key = data["key"] as? String ?: return null,
                content = data["content"] as? String ?: "",
                category = data["category"] as? String ?: "general",
                timestamp = (data["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        } catch (e: Exception) {
            Log.w(TAG, "mapToMemory", e)
            null
        }
    }

    private fun mapToTodo(data: Map<String, Any?>, userId: String): TodoEntity? {
        return try {
            TodoEntity(
                id = 0,
                userId = (data["userId"] as? String) ?: userId,
                title = data["title"] as? String ?: return null,
                isCompleted = data["isCompleted"] as? Boolean ?: false,
                category = data["category"] as? String ?: "عام",
                createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        private const val TAG = "SmartSync"
        private const val DEBOUNCE_MS = 1500L
    }
}

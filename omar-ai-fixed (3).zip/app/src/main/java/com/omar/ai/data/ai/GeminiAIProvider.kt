package com.omar.ai.data.ai

import android.util.Base64
import android.util.Log
import com.omar.ai.data.local.ChatMessageEntity
import com.omar.ai.data.local.MemoryEntity
import com.omar.ai.data.model.ActionCall
import com.omar.ai.data.model.AssistantMode
import com.omar.ai.data.model.Role
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeBackend
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerativeModel
import com.google.firebase.ai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.regex.Pattern

/**
 * Gemini via Firebase AI Logic (Gemini Developer API).
 * Tries several current model names for compatibility.
 */
class GeminiAIProvider : AIProvider {
    override val providerName: String = "Gemini (Firebase AI)"

    // Prefer newest stable names first (Firebase AI Logic docs, 2026)
    // Only Gemini 3.x – 1.5/2.0 are retired (error: models are retired as of Sep 2025)
    private val candidateModels = listOf(
        "gemini-3.8-flash",
        "gemini-3.7-flash",
        "gemini-3.5-flash",
        "gemini-3.5-flash-lite"
    )

    @Volatile
    private var activeModelName: String? = null

    private fun createModel(name: String): GenerativeModel {
        return Firebase.ai(backend = GenerativeBackend.googleAI())
            .generativeModel(modelName = name)
    }

    private suspend fun withWorkingModel(block: suspend (GenerativeModel, String) -> AIResponse): AIResponse {
        val tried = mutableListOf<String>()
        // Try cached model first
        activeModelName?.let { cached ->
            try {
                return block(createModel(cached), cached)
            } catch (e: Exception) {
                Log.w("GeminiAI", "Cached model $cached failed: ${e.message}")
                activeModelName = null
                tried += cached
            }
        }
        var lastError: Exception? = null
        for (name in candidateModels) {
            if (name in tried) continue
            try {
                val result = block(createModel(name), name)
                activeModelName = name
                Log.i("GeminiAI", "Using model: $name")
                return result
            } catch (e: Exception) {
                lastError = e
                Log.w("GeminiAI", "Model $name failed: ${e.javaClass.simpleName} ${e.message}")
            }
        }
        throw lastError ?: Exception("No Gemini model available")
    }

    override suspend fun generateResponse(
        conversationHistory: List<ChatMessageEntity>,
        userMessage: String,
        userImageBase64: String?,
        mode: AssistantMode,
        longTermMemories: List<MemoryEntity>
    ): AIResponse = withContext(Dispatchers.IO) {
        try {
            detectLocalIntent(userMessage)?.let { action ->
                return@withContext AIResponse(
                    text = "تم تنفيذ الطلب: ${action.title}",
                    actionCall = action,
                    suggestions = listOf("متابعة", "مساعدة أخرى")
                )
            }

            if (isVideoGenerationIntent(userMessage)) {
                return@withContext AIResponse(
                    text = "توليد الفيديو غير مدعوم حاليًا. صف المشهد وسأساعدك بوصف أو صورة.",
                    suggestions = listOf("أنشئ صورة بدلاً من ذلك", "وصف المشهد")
                )
            }

            if (isImageGenerationIntent(userMessage)) {
                return@withContext AIResponse(
                    text = "توليد الصور المباشر غير مفعّل في هذه النسخة. صف الصورة بالتفصيل وسأساعدك بالنص.",
                    suggestions = listOf("صف الصورة بالتفصيل", "مساعدة أخرى")
                )
            }

            val systemInstruction = buildSystemInstruction(mode, longTermMemories)

            withWorkingModel { model, _ ->
                // Build simple multi-turn history without heavy system preamble spam
                val history = mutableListOf<Content>()
                for (msg in conversationHistory.takeLast(10)) {
                    val role = if (msg.role == Role.USER.name) "user" else "model"
                    val text = msg.content.trim()
                    if (text.isBlank() && msg.imageBase64.isNullOrBlank()) continue
                    history.add(
                        content(role = role) {
                            if (text.isNotBlank()) text(text)
                            if (!msg.imageBase64.isNullOrBlank()) {
                                try {
                                    val bytes = Base64.decode(msg.imageBase64, Base64.DEFAULT)
                                    inlineData(bytes, "image/jpeg")
                                } catch (e: Exception) {
                                    Log.w("GeminiAI", "history image decode failed", e)
                                }
                            }
                        }
                    )
                }

                val userContent = content(role = "user") {
                    // Inject system guidance only on first turn of this request
                    if (history.isEmpty()) {
                        text("$systemInstruction\n\n---\n$userMessage")
                    } else {
                        text(userMessage)
                    }
                    if (!userImageBase64.isNullOrBlank()) {
                        try {
                            val bytes = Base64.decode(userImageBase64, Base64.DEFAULT)
                            inlineData(bytes, "image/jpeg")
                        } catch (e: Exception) {
                            Log.w("GeminiAI", "user image decode failed", e)
                        }
                    }
                }

                val response = if (history.isEmpty()) {
                    model.generateContent(userContent)
                } else {
                    // Prepend a lightweight system exchange once
                    val withSystem = listOf(
                        content(role = "user") { text(systemInstruction) },
                        content(role = "model") { text("OK") }
                    ) + history
                    val chat = model.startChat(history = withSystem)
                    chat.sendMessage(userContent)
                }

                val fullText = response.text?.trim().orEmpty()
                if (fullText.isBlank()) {
                    return@withWorkingModel AIResponse(
                        text = "لم أتمكن من توليد رد. حاول مرة أخرى.",
                        isError = true,
                        errorMessage = "Empty model response"
                    )
                }

                val (cleanText, actionCall) = extractAction(fullText)
                val (finalText, suggestions) = extractSuggestions(cleanText, mode)

                AIResponse(
                    text = finalText.ifBlank { fullText },
                    actionCall = actionCall,
                    suggestions = suggestions
                )
            }
        } catch (e: Exception) {
            Log.e("GeminiAI", "generateResponse failed", e)
            val detail = e.message ?: e.cause?.message ?: e.javaClass.simpleName
            val msg = when {
                detail.contains("App Check", ignoreCase = true) ||
                        detail.contains("appcheck", ignoreCase = true) ||
                        detail.contains("403", ignoreCase = true) && detail.contains("attestation", ignoreCase = true) ->
                    "تم حظر الطلب بسبب App Check. في Firebase Console → App Check عطّل Enforcement مؤقتًا للتطوير، أو سجّل Debug Token."

                detail.contains("not found", ignoreCase = true) ||
                        detail.contains("NOT_FOUND", ignoreCase = true) ||
                        detail.contains("was not found", ignoreCase = true) ->
                    "اسم نموذج Gemini غير متاح لمشروعك. من Firebase Console → AI Logic تأكد من تفعيل Gemini Developer API."

                detail.contains("PERMISSION", ignoreCase = true) ||
                        detail.contains("permission_denied", ignoreCase = true) ||
                        detail.contains("API has not been used", ignoreCase = true) ||
                        detail.contains("not enabled", ignoreCase = true) ->
                    "Gemini غير مفعّل. افتح Firebase Console → Build → AI Logic وفعّل Gemini Developer API لمشروع omar-ai-67541."

                detail.contains("UNAUTHENTICATED", ignoreCase = true) ||
                        detail.contains("401", ignoreCase = true) ->
                    "المصادقة فشلت مع Firebase AI. تأكد من google-services.json وأن التطبيق مسجّل في المشروع."

                detail.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ||
                        detail.contains("quota", ignoreCase = true) ||
                        detail.contains("429", ignoreCase = true) ->
                    "تم تجاوز حد الاستخدام (Quota). انتظر قليلًا أو راجع الحصة في Google AI / Firebase."

                detail.contains("network", ignoreCase = true) ||
                        detail.contains("Unable to resolve", ignoreCase = true) ||
                        detail.contains("UNAVAILABLE", ignoreCase = true) ->
                    "لا يوجد اتصال بالإنترنت أو الخدمة غير متاحة."

                detail.contains("ServerException", ignoreCase = true) ||
                        e.javaClass.simpleName.contains("Server", ignoreCase = true) ->
                    "خطأ من خادم Gemini ($detail). غالبًا: نموذج غير مدعوم أو AI Logic غير مفعّل. فعّل AI Logic في Firebase وجرّب مرة أخرى."

                else ->
                    "حدث خطأ أثناء الاتصال بـ Omar AI.\n$detail"
            }
            AIResponse(
                text = msg,
                isError = true,
                errorMessage = detail
            )
        }
    }

    override suspend fun generateTitle(firstUserMessage: String): String = withContext(Dispatchers.IO) {
        try {
            val prompt =
                "Generate a very short conversation title (max 6 words) in the same language as the user message. No quotes. Message: $firstUserMessage"
            withWorkingModel { model, _ ->
                val response = model.generateContent(prompt)
                val t = response.text?.trim()?.take(60)?.ifBlank { null }
                    ?: firstUserMessage.take(40).ifBlank { "محادثة جديدة" }
                AIResponse(text = t)
            }.text
        } catch (e: Exception) {
            Log.w("GeminiAI", "title gen failed", e)
            firstUserMessage.take(40).ifBlank { "محادثة جديدة" }
        }
    }

    override suspend fun generateImage(prompt: String): Result<String> =
        Result.failure(Exception("Image generation is not enabled in this build."))

    private fun buildSystemInstruction(mode: AssistantMode, memories: List<MemoryEntity>): String {
        val memoryContext = if (memories.isNotEmpty()) {
            "Tracked User Memories (strict facts – never invent):\n" +
                    memories.joinToString("\n") { "- [${it.category}/${it.key}] ${it.content}" } +
                    "\nRefer only to the exact data above for personal facts."
        } else ""

        val modeInstruction = when (mode) {
            AssistantMode.GENERAL -> "Mode: General Assistant. Adaptive, concise, helpful."
            AssistantMode.STUDY -> "Mode: Study Tutor. Clear explanations, step-by-step, summaries."
            AssistantMode.CODING -> "Mode: Expert Engineer. Clean code in markdown, diagnosis."
            AssistantMode.WORK -> "Mode: Executive Assistant. Professional drafting, structured plans."
        }

        return """
            You are Omar AI (OMAR AI), an elite personal AI assistant.
            Respectful, concise, proactive and natural.
            Understand and reply in Arabic (all dialects), English, French, and mixed Arabic-English naturally. Match the user language. Tolerate typos.
            $modeInstruction
            $memoryContext

            When a phone action is needed, append at the very end:
            ```action
            {"action":"ACTION_NAME","title":"short title","parameters":{}}
            ```
            Supported: TORCH_ON, TORCH_OFF, OPEN_CAMERA, TAKE_PHOTO, OPEN_WHATSAPP,
            OPEN_SETTINGS, OPEN_YOUTUBE, OPEN_CHROME, VOLUME_UP, VOLUME_DOWN,
            SET_TIMER, SET_ALARM, CREATE_REMINDER, ADD_TODO, CALL_CONTACT, SEARCH_WEB.

            Always end with 2-3 suggestions:
            ```suggestions
            ["s1","s2","s3"]
            ```
        """.trimIndent()
    }

    private fun extractAction(text: String): Pair<String, ActionCall?> {
        val pattern = Pattern.compile("```action\\s*\\n?([\\s\\S]*?)```", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(text)
        var actionCall: ActionCall? = null
        var clean = text
        if (matcher.find()) {
            val jsonStr = matcher.group(1)?.trim().orEmpty()
            clean = text.replace(matcher.group(0) ?: "", "").trim()
            try {
                val obj = org.json.JSONObject(jsonStr)
                val name = obj.optString("action", "")
                val title = obj.optString("title", name)
                val params = mutableMapOf<String, String>()
                obj.optJSONObject("parameters")?.let { p ->
                    p.keys().forEach { key -> params[key] = p.optString(key) }
                }
                if (name.isNotBlank()) {
                    actionCall = ActionCall(name, title, params)
                }
            } catch (e: Exception) {
                Log.w("GeminiAI", "action parse failed", e)
            }
        }
        return clean to actionCall
    }

    private fun extractSuggestions(text: String, mode: AssistantMode): Pair<String, List<String>> {
        val pattern = Pattern.compile("```suggestions\\s*\\n?([\\s\\S]*?)```", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(text)
        val suggestions = mutableListOf<String>()
        var clean = text
        if (matcher.find()) {
            val block = matcher.group(1)?.trim().orEmpty()
            clean = text.replace(matcher.group(0) ?: "", "").trim()
            try {
                val arr = org.json.JSONArray(block)
                for (i in 0 until arr.length()) suggestions.add(arr.getString(i))
            } catch (_: Exception) {
                block.lines()
                    .map { it.trim().removePrefix("-").removePrefix("*").trim() }
                    .filter { it.isNotBlank() && !it.startsWith("[") }
                    .take(3)
                    .forEach { suggestions.add(it) }
            }
        }
        if (suggestions.isEmpty()) {
            when (mode) {
                AssistantMode.STUDY -> suggestions.addAll(listOf("اختبرني", "لخص النقاط", "Flashcards"))
                AssistantMode.CODING -> suggestions.addAll(listOf("ابحث عن أخطاء", "حسّن الأداء", "اشرح الكود"))
                AssistantMode.WORK -> suggestions.addAll(listOf("صياغة رسمية", "خطة عمل", "ملخص"))
                AssistantMode.GENERAL -> suggestions.addAll(listOf("المزيد", "مثال", "الخطوة التالية"))
            }
        }
        return clean to suggestions.take(3)
    }

    private fun isVideoGenerationIntent(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("ولد فيديو") || lower.contains("أنشئ فيديو") ||
                lower.contains("generate video") || lower.contains("create video") ||
                lower.contains("اصنع فيديو")
    }

    private fun isImageGenerationIntent(text: String): Boolean {
        val lower = text.lowercase().trim()
        return lower.startsWith("أنشئ صورة") || lower.startsWith("ولد صورة") ||
                lower.startsWith("اصنع صورة") || lower.startsWith("ارسم") ||
                lower.startsWith("توليد صورة") || lower.startsWith("generate image") ||
                lower.startsWith("create image") || lower.startsWith("draw")
    }

    private fun detectLocalIntent(text: String): ActionCall? {
        val clean = text.trim().lowercase()
        return when {
            clean.contains("شغل الفلاش") || clean.contains("شغل الكشاف") || clean.contains("turn on flashlight") ->
                ActionCall("TORCH_ON", "تشغيل الفلاش")
            clean.contains("اطفي الفلاش") || clean.contains("اطفئ الفلاش") || clean.contains("اقفل الكشاف") || clean.contains("turn off flashlight") ->
                ActionCall("TORCH_OFF", "إطفاء الفلاش")
            clean.contains("التقط صورة") || clean.contains("صور صورة") || clean.contains("take photo") ->
                ActionCall("TAKE_PHOTO", "التقاط صورة")
            clean.contains("افتح الكاميرا") || clean.contains("شغل الكاميرا") || clean.contains("open camera") ->
                ActionCall("OPEN_CAMERA", "فتح الكاميرا")
            clean.contains("افتح واتساب") || clean.contains("افتح whatsapp") || clean.contains("open whatsapp") ->
                ActionCall("OPEN_WHATSAPP", "فتح WhatsApp")
            clean.contains("افتح الإعدادات") || clean.contains("افتح الضبط") || clean.contains("open settings") ->
                ActionCall("OPEN_SETTINGS", "فتح الإعدادات")
            clean.contains("افتح يوتيوب") || clean.contains("افتح youtube") || clean.contains("open youtube") ->
                ActionCall("OPEN_YOUTUBE", "فتح YouTube")
            clean.contains("افتح كروم") || clean.contains("افتح chrome") || clean.contains("open chrome") ->
                ActionCall("OPEN_CHROME", "فتح Chrome")
            clean.contains("ارفع الصوت") || clean.contains("علي الصوت") || clean.contains("volume up") ->
                ActionCall("VOLUME_UP", "رفع مستوى الصوت")
            clean.contains("اخفض الصوت") || clean.contains("وطي الصوت") || clean.contains("volume down") ->
                ActionCall("VOLUME_DOWN", "خفض مستوى الصوت")
            clean.startsWith("اتصل ب") || clean.startsWith("call ") -> {
                val name = clean.removePrefix("اتصل ب").removePrefix("call ").trim()
                ActionCall("CALL_CONTACT", "الاتصال بـ $name", mapOf("name" to name), requiresConfirmation = true)
            }
            else -> null
        }
    }
}

package com.omar.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface OmarDao {
    // --- Conversations (scoped by userId) ---
    @Query("SELECT * FROM conversations WHERE userId = :userId AND isTemporary = 0 AND isArchived = 0 ORDER BY isPinned DESC, updatedAt DESC")
    fun getActiveConversations(userId: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE userId = :userId AND isTemporary = 0 AND isArchived = 0 ORDER BY isPinned DESC, updatedAt DESC")
    suspend fun getActiveConversationsList(userId: String): List<ConversationEntity>

    @Query("SELECT * FROM conversations WHERE userId = :userId AND isTemporary = 0 ORDER BY updatedAt DESC")
    suspend fun getAllUserConversationsList(userId: String): List<ConversationEntity>

    @Query("SELECT * FROM conversations WHERE userId = :userId AND isTemporary = 0 AND isArchived = 1 ORDER BY updatedAt DESC")
    fun getArchivedConversations(userId: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id AND userId = :userId LIMIT 1")
    suspend fun getConversationById(id: String, userId: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity)

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    @Query("UPDATE conversations SET title = :newTitle, updatedAt = :updatedAt WHERE id = :id AND userId = :userId")
    suspend fun updateConversationTitle(id: String, userId: String, newTitle: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE conversations SET isPinned = :isPinned WHERE id = :id AND userId = :userId")
    suspend fun setConversationPinned(id: String, userId: String, isPinned: Boolean)

    @Query("UPDATE conversations SET isArchived = :isArchived WHERE id = :id AND userId = :userId")
    suspend fun setConversationArchived(id: String, userId: String, isArchived: Boolean)

    @Query("UPDATE conversations SET updatedAt = :updatedAt WHERE id = :id AND userId = :userId")
    suspend fun touchConversation(id: String, userId: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM conversations WHERE id = :id AND userId = :userId")
    suspend fun deleteConversation(id: String, userId: String)

    @Query("DELETE FROM conversations WHERE userId = :userId AND isTemporary = 1")
    suspend fun deleteTemporaryConversations(userId: String)

    @Query("DELETE FROM conversations WHERE userId = :userId")
    suspend fun clearAllConversations(userId: String)

    @Query("SELECT * FROM conversations WHERE userId = :userId AND isTemporary = 0 AND (title LIKE '%' || :query || '%') ORDER BY updatedAt DESC")
    fun searchConversations(userId: String, query: String): Flow<List<ConversationEntity>>

    // --- Messages ---
    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesListForConversation(conversationId: String): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Update
    suspend fun updateMessage(message: ChatMessageEntity)

    @Query("UPDATE chat_messages SET content = :content, status = :status WHERE id = :id")
    suspend fun updateMessageContent(id: String, content: String, status: String)

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("DELETE FROM chat_messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)

    @Query("DELETE FROM chat_messages WHERE userId = :userId")
    suspend fun clearAllMessages(userId: String)

    // --- Memory (scoped by userId) ---
    @Query("SELECT * FROM memories WHERE userId = :userId ORDER BY createdAt DESC")
    fun getAllMemories(userId: String): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE userId = :userId ORDER BY createdAt DESC")
    suspend fun getMemoriesList(userId: String): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE userId = :userId AND `key` = :key LIMIT 1")
    suspend fun getMemoryByKey(userId: String, key: String): MemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id AND userId = :userId")
    suspend fun deleteMemory(id: Long, userId: String)

    @Query("DELETE FROM memories WHERE userId = :userId")
    suspend fun clearAllMemories(userId: String)

    // --- Todos ---
    @Query("SELECT * FROM todos WHERE userId = :userId ORDER BY isCompleted ASC, createdAt DESC")
    fun getAllTodos(userId: String): Flow<List<TodoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodo(todo: TodoEntity): Long

    @Update
    suspend fun updateTodo(todo: TodoEntity)

    @Query("UPDATE todos SET isCompleted = :completed WHERE id = :id AND userId = :userId")
    suspend fun toggleTodo(id: Long, userId: String, completed: Boolean)

    @Query("DELETE FROM todos WHERE id = :id AND userId = :userId")
    suspend fun deleteTodo(id: Long, userId: String)

    @Query("DELETE FROM todos WHERE userId = :userId")
    suspend fun clearAllTodos(userId: String)

    // --- Reminders ---
    @Query("SELECT * FROM reminders WHERE userId = :userId AND isTriggered = 0 ORDER BY triggerTimeMillis ASC")
    fun getActiveReminders(userId: String): Flow<List<ReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity): Long

    @Query("UPDATE reminders SET isTriggered = 1 WHERE id = :id AND userId = :userId")
    suspend fun markReminderTriggered(id: Long, userId: String)

    @Query("DELETE FROM reminders WHERE id = :id AND userId = :userId")
    suspend fun deleteReminder(id: Long, userId: String)
}

package com.omar.ai.data.action

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import com.omar.ai.data.local.OmarDao
import com.omar.ai.data.local.ReminderEntity
import com.omar.ai.data.local.TodoEntity
import com.omar.ai.data.model.ActionCall
import com.omar.ai.data.model.ContactMatch

class ActionDispatcher(
    private val context: Context,
    private val omarDao: OmarDao
) {
    private fun currentUserId(): String {
        val prefs = context.getSharedPreferences("omar_ai_auth_prefs", Context.MODE_PRIVATE)
        return prefs.getString("user_uid", null) ?: "guest_local"
    }
    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    }

    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    suspend fun executeAction(action: ActionCall): ActionResult {
        return try {
            when (action.actionType) {
                "TORCH_ON" -> {
                    setTorch(true)
                    ActionResult.Success("تم تشغيل كشاف الهاتف 🔦")
                }
                "TORCH_OFF" -> {
                    setTorch(false)
                    ActionResult.Success("تم إطفاء كشاف الهاتف 🔦")
                }
                "OPEN_CAMERA" -> {
                    val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("تم فتح الكاميرا 📷")
                }
                "TAKE_PHOTO" -> {
                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("تم فتح التقاط الصورة 📸")
                }
                "OPEN_WHATSAPP" -> {
                    val packageManager = context.packageManager
                    val launchIntent = packageManager.getLaunchIntentForPackage("com.whatsapp")
                        ?: packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
                    if (launchIntent != null) {
                        launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        context.startActivity(launchIntent)
                        ActionResult.Success("تم فتح تطبيق WhatsApp 💬")
                    } else {
                        val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.whatsapp")).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(playStoreIntent)
                        ActionResult.Success("جاري فتح متجر التطبيقات لتثبيت WhatsApp 💬")
                    }
                }
                "OPEN_SETTINGS" -> {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("تم فتح الإعدادات ⚙️")
                }
                "OPEN_YOUTUBE" -> {
                    val query = action.parameters["query"]
                    val intent = if (!query.isNullOrBlank()) {
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}"))
                    } else {
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                    }.apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success(if (query.isNullOrBlank()) "تم فتح YouTube ▶️" else "جاري البحث في YouTube عن: $query")
                }
                "OPEN_CHROME", "SEARCH_WEB" -> {
                    val urlOrQuery = action.parameters["url"] ?: action.parameters["query"] ?: ""
                    val uri = if (urlOrQuery.startsWith("http://") || urlOrQuery.startsWith("https://")) {
                        Uri.parse(urlOrQuery)
                    } else {
                        Uri.parse("https://www.google.com/search?q=${Uri.encode(urlOrQuery)}")
                    }
                    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("تم فتح المتصفح 🌐")
                }
                "VOLUME_UP" -> {
                    audioManager?.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_RAISE,
                        AudioManager.FLAG_SHOW_UI
                    )
                    ActionResult.Success("تم رفع مستوى الصوت 🔊")
                }
                "VOLUME_DOWN" -> {
                    audioManager?.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI
                    )
                    ActionResult.Success("تم خفض مستوى الصوت 🔉")
                }
                "SET_TIMER" -> {
                    val seconds = action.parameters["seconds"]?.toIntOrNull() ?: 60
                    val message = action.parameters["message"] ?: "Omar AI Timer"
                    val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                        putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                        putExtra(AlarmClock.EXTRA_MESSAGE, message)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("تم ضبط المؤقت لمدة $seconds ثانية ⏱️")
                }
                "SET_ALARM" -> {
                    val hour = action.parameters["hour"]?.toIntOrNull() ?: 7
                    val minute = action.parameters["minute"]?.toIntOrNull() ?: 0
                    val message = action.parameters["message"] ?: "Omar AI Alarm"
                    val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        putExtra(AlarmClock.EXTRA_MESSAGE, message)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("تم ضبط المنبه على الساعة $hour:${minute.toString().padStart(2, '0')} ⏰")
                }
                "CREATE_REMINDER" -> {
                    val title = action.parameters["title"] ?: "تذكير Omar AI"
                    val minutesFromNow = action.parameters["minutesFromNow"]?.toLongOrNull() ?: 15L
                    val triggerTime = System.currentTimeMillis() + (minutesFromNow * 60 * 1000L)
                    omarDao.insertReminder(
                        ReminderEntity(
                            userId = currentUserId(),
                            title = title,
                            triggerTimeMillis = triggerTime
                        )
                    )
                    ActionResult.Success("تم حفظ التذكير: \"$title\" بعد $minutesFromNow دقيقة 🔔")
                }
                "ADD_TODO" -> {
                    val task = action.parameters["task"] ?: "مهمة جديدة"
                    val category = action.parameters["category"] ?: "عام"
                    omarDao.insertTodo(
                        TodoEntity(
                            userId = currentUserId(),
                            title = task,
                            category = category
                        )
                    )
                    ActionResult.Success("تمت إضافة المهمة إلى قائمة المهام: \"$task\" ✅")
                }
                else -> {
                    ActionResult.Error("نوع الإجراء غير معروف: ${action.actionType}")
                }
            }
        } catch (e: Exception) {
            Log.e("ActionDispatcher", "Failed to execute action ${action.actionType}", e)
            ActionResult.Error("تعذر تنفيذ الإجراء: ${e.localizedMessage ?: "حدث خطأ غير متوقع"}")
        }
    }

    fun searchContacts(query: String): List<ContactMatch> {
        val matches = mutableListOf<ContactMatch>()
        try {
            val contentResolver = context.contentResolver
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$query%")

            contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (cursor.moveToNext() && matches.size < 10) {
                    val id = cursor.getString(idIdx) ?: ""
                    val name = cursor.getString(nameIdx) ?: ""
                    val number = cursor.getString(numberIdx) ?: ""
                    if (name.isNotBlank() && number.isNotBlank()) {
                        matches.add(ContactMatch(id, name, number))
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.w("ActionDispatcher", "Permission READ_CONTACTS not granted", e)
        } catch (e: Exception) {
            Log.e("ActionDispatcher", "Error searching contacts", e)
        }
        return matches
    }

    fun startDialer(phoneNumber: String) {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phoneNumber)}")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("ActionDispatcher", "Failed to open dialer", e)
        }
    }

    private fun setTorch(enabled: Boolean) {
        val cm = cameraManager ?: return
        try {
            val cameraId = cm.cameraIdList.firstOrNull() ?: return
            cm.setTorchMode(cameraId, enabled)
        } catch (e: CameraAccessException) {
            Log.e("ActionDispatcher", "Torch mode error", e)
        }
    }
}

sealed class ActionResult {
    data class Success(val message: String) : ActionResult()
    data class Error(val errorMessage: String) : ActionResult()
}

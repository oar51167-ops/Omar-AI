package com.omar.ai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ConversationEntity::class,
        ChatMessageEntity::class,
        MemoryEntity::class,
        TodoEntity::class,
        ReminderEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class OmarDatabase : RoomDatabase() {
    abstract fun omarDao(): OmarDao

    companion object {
        @Volatile
        private var INSTANCE: OmarDatabase? = null

        fun getDatabase(context: Context): OmarDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    OmarDatabase::class.java,
                    "omar_ai_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

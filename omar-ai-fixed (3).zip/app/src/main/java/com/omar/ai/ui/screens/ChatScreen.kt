package com.omar.ai.ui.screens

import android.Manifest
import android.widget.Toast
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuOpen
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.omar.ai.R
import com.omar.ai.data.model.AssistantMode
import com.omar.ai.ui.OmarStrings
import com.omar.ai.ui.OmarViewModel
import com.omar.ai.ui.components.ChatBubble
import com.omar.ai.ui.components.ChatComposer
import com.omar.ai.ui.components.SideDrawerContent
import com.omar.ai.ui.components.VoiceOverlay
import com.omar.ai.ui.dialogs.ContactCallConfirmationDialog
import com.omar.ai.ui.dialogs.MemoryManagerDialog
import com.omar.ai.ui.dialogs.SettingsDialog
import com.omar.ai.ui.dialogs.TodoManagerDialog
import com.omar.ai.ui.theme.CyanAccent
import com.omar.ai.ui.theme.ElectricBlue
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: OmarViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val isArabic by viewModel.isArabic.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val autoSpeak by viewModel.autoSpeak.collectAsState()
    val voiceSpeed by viewModel.voiceSpeed.collectAsState()
    var smartSyncEnabled by remember { mutableStateOf(viewModel.isSmartSyncEnabled()) }
    val selectedMode by viewModel.selectedMode.collectAsState()

    val currentConvId by viewModel.currentConversationId.collectAsState()
    val conversations by viewModel.conversations.collectAsState()
    val messages by viewModel.currentMessages.collectAsState()
    val memories by viewModel.memories.collectAsState()
    val todos by viewModel.todos.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val isGenerating by viewModel.isGenerating.collectAsState()
    val attachedImageUri by viewModel.attachedImageUri.collectAsState()
    val attachedFileName by viewModel.attachedFileName.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    val liveSpokenText by viewModel.liveSpokenText.collectAsState()
    val voiceError by viewModel.voiceError.collectAsState()
    val pendingActionCall by viewModel.pendingActionCall.collectAsState()
    val contactMatches by viewModel.contactMatches.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    LaunchedEffect(voiceError) {
        val err = voiceError
        if (!err.isNullOrBlank()) {
            Toast.makeText(context, err, Toast.LENGTH_LONG).show()
            viewModel.clearVoiceError()
        }
    }

    var showVoiceOverlay by remember { mutableStateOf(false) }
    var showMemoryDialog by remember { mutableStateOf(false) }
    var showTodoSheet by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showModeDropdown by remember { mutableStateOf(false) }
    var showTopMenu by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    // Permission launcher for Voice Audio
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            showVoiceOverlay = true
            viewModel.startVoiceListening()
        }
    }

    // Auto-scroll on new message
    LaunchedEffect(messages.size, isGenerating) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val activeConv = conversations.find { it.id == currentConvId }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            SideDrawerContent(
                isArabic = isArabic,
                currentUser = currentUser,
                conversations = conversations,
                currentConversationId = currentConvId,
                searchQuery = searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onNewChatClick = { isTemp ->
                    coroutineScope.launch { drawerState.close() }
                    viewModel.startNewConversation(isTemp)
                },
                onSelectConversation = { id ->
                    coroutineScope.launch { drawerState.close() }
                    viewModel.selectConversation(id)
                },
                onRenameConversation = { id, title -> viewModel.renameConversation(id, title) },
                onTogglePin = { id, pinned -> viewModel.togglePinConversation(id, pinned) },
                onArchiveConversation = { id -> viewModel.archiveConversation(id) },
                onDeleteConversation = { id -> viewModel.deleteConversation(id) },
                onOpenMemoryDialog = {
                    coroutineScope.launch { drawerState.close() }
                    showMemoryDialog = true
                },
                onOpenTodoSheet = {
                    coroutineScope.launch { drawerState.close() }
                    showTodoSheet = true
                },
                onOpenSettingsDialog = {
                    coroutineScope.launch { drawerState.close() }
                    showSettingsDialog = true
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = activeConv?.title ?: OmarStrings.appName(isArabic),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (activeConv?.isTemporary == true) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = OmarStrings.temporaryChat(isArabic),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            // Mode selector chip
                            Box {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { showModeDropdown = true }
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${selectedMode.icon} ${if (isArabic) selectedMode.titleAr else selectedMode.titleEn}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                DropdownMenu(
                                    expanded = showModeDropdown,
                                    onDismissRequest = { showModeDropdown = false }
                                ) {
                                    AssistantMode.values().forEach { mode ->
                                        DropdownMenuItem(
                                            text = {
                                                Text("${mode.icon} ${if (isArabic) mode.titleAr else mode.titleEn}")
                                            },
                                            onClick = {
                                                viewModel.setMode(mode)
                                                showModeDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(
                                imageVector = if (isArabic) Icons.AutoMirrored.Filled.MenuOpen else Icons.Default.Menu,
                                contentDescription = "Open Drawer"
                            )
                        }
                    },
                    actions = {
                        // Voice Chat Button
                        IconButton(onClick = {
                            val hasPermission = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED

                            if (hasPermission) {
                                showVoiceOverlay = true
                                viewModel.startVoiceListening()
                            } else {
                                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = OmarStrings.voiceChat(isArabic),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Overflow Options Menu
                        Box {
                            IconButton(onClick = { showTopMenu = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(
                                expanded = showTopMenu,
                                onDismissRequest = { showTopMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(OmarStrings.newChat(isArabic)) },
                                    leadingIcon = { Icon(Icons.Default.Add, contentDescription = null) },
                                    onClick = {
                                        showTopMenu = false
                                        viewModel.startNewConversation()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(OmarStrings.clearAll(isArabic)) },
                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                                    onClick = {
                                        showTopMenu = false
                                        currentConvId?.let { viewModel.deleteConversation(it) }
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                ChatComposer(
                    isArabic = isArabic,
                    attachedImageUri = attachedImageUri,
                    attachedFileName = attachedFileName,
                    onAttachImage = { viewModel.attachImage(it) },
                    onClearAttachedImage = { viewModel.clearAttachedImage() },
                    onSendMessage = { viewModel.sendMessage(it) },
                    onVoiceClick = {
                        val hasPermission = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED

                        if (hasPermission) {
                            showVoiceOverlay = true
                            viewModel.startVoiceListening()
                        } else {
                            recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    isGenerating = isGenerating
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (messages.isEmpty()) {
                    // Empty Chat Welcome View
                    EmptyChatGreeting(
                        isArabic = isArabic,
                        selectedMode = selectedMode,
                        onPromptClick = { viewModel.sendMessage(it) }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            ChatBubble(
                                message = msg,
                                isArabic = isArabic,
                                onEditSave = { newContent ->
                                    viewModel.editUserMessage(msg.id, newContent)
                                },
                                onDelete = { viewModel.deleteMessage(msg.id) },
                                onRegenerate = { viewModel.regenerateLastResponse() },
                                onSpeak = { viewModel.speakText(it) },
                                onSuggestionClick = { viewModel.sendMessage(it) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Voice Overlay
    AnimatedVisibility(
        visible = showVoiceOverlay,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        VoiceOverlay(
            isArabic = isArabic,
            voiceState = voiceState,
            liveSpokenText = liveSpokenText,
            onStartListening = { viewModel.startVoiceListening() },
            onStopListening = { viewModel.stopVoiceListening() },
            onStopSpeaking = { viewModel.stopSpeaking() },
            onClose = {
                viewModel.stopVoiceListening()
                viewModel.stopSpeaking()
                showVoiceOverlay = false
            }
        )
    }

    // Contact Call Confirmation Dialog
    if (pendingActionCall != null && pendingActionCall?.actionType == "CALL_CONTACT") {
        ContactCallConfirmationDialog(
            isArabic = isArabic,
            contactMatches = contactMatches,
            targetName = pendingActionCall?.parameters?.get("name") ?: "",
            onConfirm = { contact -> viewModel.confirmContactCall(contact) },
            onCancel = { viewModel.cancelPendingAction() }
        )
    }

    // Memory Dialog
    if (showMemoryDialog) {
        MemoryManagerDialog(
            isArabic = isArabic,
            memories = memories,
            onAddMemory = { k, c, cat -> viewModel.addMemory(k, c, cat) },
            onDeleteMemory = { viewModel.deleteMemory(it) },
            onClearAll = { viewModel.clearAllMemories() },
            onDismiss = { showMemoryDialog = false }
        )
    }

    // Todo Sheet
    if (showTodoSheet) {
        TodoManagerDialog(
            isArabic = isArabic,
            todos = todos,
            onAddTodo = { viewModel.addTodo(it) },
            onToggleTodo = { id, comp -> viewModel.toggleTodo(id, comp) },
            onDeleteTodo = { viewModel.deleteTodo(it) },
            onDismiss = { showTodoSheet = false }
        )
    }

    // Settings Dialog
    if (showSettingsDialog) {
        SettingsDialog(
            isArabic = isArabic,
            currentUser = currentUser,
            themeMode = themeMode,
            autoSpeak = autoSpeak,
            voiceSpeed = voiceSpeed,
            smartSyncEnabled = smartSyncEnabled,
            onSetLanguage = { viewModel.setLanguage(it) },
            onSetThemeMode = { viewModel.setThemeMode(it) },
            onSetAutoSpeak = { viewModel.setAutoSpeak(it) },
            onSetVoiceSpeed = { viewModel.setVoiceSpeed(it) },
            onSetSmartSync = {
                smartSyncEnabled = it
                viewModel.setSmartSyncEnabled(it)
            },
            onSignOut = { viewModel.signOut() },
            onDeleteAccount = { viewModel.deleteAccountAndData() },
            onDismiss = { showSettingsDialog = false }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmptyChatGreeting(
    isArabic: Boolean,
    selectedMode: AssistantMode,
    onPromptClick: (String) -> Unit
) {
    val prompts = when (selectedMode) {
        AssistantMode.STUDY -> listOf(
            if (isArabic) "اشرح لي نظرية النسبية ببساطة" else "Explain relativity theory simply",
            if (isArabic) "لخص لي هذا الدرس في 5 نقاط" else "Summarize this lesson into 5 key points",
            if (isArabic) "حل مسألة رياضية خطوة بخطوة" else "Solve a math problem step-by-step",
            if (isArabic) "اختبرني في قواعد اللغة الإنجليزية" else "Quiz me on English grammar"
        )
        AssistantMode.CODING -> listOf(
            if (isArabic) "اكتب كود Kotlin لـ Clean Architecture" else "Write clean Kotlin MVVM code",
            if (isArabic) "ابحث عن الخطأ البرمجي وحسّنه" else "Find and fix bugs in my code",
            if (isArabic) "اشرح مفهوم Coroutines في أندرويد" else "Explain Android Coroutines flow",
            if (isArabic) "أنشئ واجهة Jetpack Compose حديثة" else "Build a modern Jetpack Compose screen"
        )
        AssistantMode.WORK -> listOf(
            if (isArabic) "صغ لي إيميل اعتذار رسمي ومهني" else "Draft a professional business email",
            if (isArabic) "أنشئ خطة عمل لمشروع جديد" else "Create a project execution plan",
            if (isArabic) "لخص نقاط الاجتماع التنفيذي" else "Summarize executive meeting notes",
            if (isArabic) "حلل استراتيجية تسويق رقمي" else "Analyze a digital marketing plan"
        )
        AssistantMode.GENERAL -> listOf(
            if (isArabic) "شغل الفلاش" else "Turn on flashlight",
            if (isArabic) "أنشئ صورة لمدينة ذكية مستقبلية" else "Create image of a futuristic cyber city",
            if (isArabic) "ما هي أحدث أخبار الذكاء الاصطناعي؟" else "What is new in AI?",
            if (isArabic) "اضبط مؤقت لمدة دقيقتين" else "Set a 2-minute timer"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(ElectricBlue, CyanAccent)))
                .border(2.dp, Color(0xFF38BDF8), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_omar_logo),
                contentDescription = "Omar AI",
                modifier = Modifier
                    .size(70.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = OmarStrings.welcomeNewChat(isArabic),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (p in prompts) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onPromptClick(p) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = p,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

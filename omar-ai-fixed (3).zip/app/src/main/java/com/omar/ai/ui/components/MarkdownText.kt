package com.omar.ai.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omar.ai.ui.theme.CodeBackground
import com.omar.ai.ui.theme.CodeText

@Composable
fun MarkdownContent(
    content: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val context = LocalContext.current
    val blocks = splitContentIntoBlocks(content)

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (block in blocks) {
            when (block) {
                is Block.Code -> {
                    CodeBlockView(
                        language = block.language,
                        code = block.code,
                        onCopy = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Code", block.code))
                            Toast.makeText(context, "تم نسخ الكود", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                is Block.Text -> {
                    val annotated = parseFormattedText(block.text, textColor)
                    Text(
                        text = annotated,
                        style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 24.sp),
                        color = textColor
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlockView(
    language: String,
    code: String,
    onCopy: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CodeBackground)
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
    ) {
        // Top header bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF131B2E))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.ifBlank { "code" }.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF94A3B8),
                fontWeight = FontWeight.Bold
            )
            IconButton(
                onClick = onCopy,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy code",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Code content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Text(
                text = code,
                color = CodeText,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 20.sp
            )
        }
    }
}

sealed class Block {
    data class Text(val text: String) : Block()
    data class Code(val language: String, val code: String) : Block()
}

fun splitContentIntoBlocks(content: String): List<Block> {
    val blocks = mutableListOf<Block>()
    val lines = content.lines()
    var inCodeBlock = false
    var currentLanguage = ""
    val currentCodeLines = mutableListOf<String>()
    val currentTextLines = mutableListOf<String>()

    for (line in lines) {
        if (line.trim().startsWith("```")) {
            if (inCodeBlock) {
                // End code block
                blocks.add(Block.Code(currentLanguage, currentCodeLines.joinToString("\n")))
                currentCodeLines.clear()
                currentLanguage = ""
                inCodeBlock = false
            } else {
                // Flush text if any
                if (currentTextLines.isNotEmpty()) {
                    blocks.add(Block.Text(currentTextLines.joinToString("\n")))
                    currentTextLines.clear()
                }
                currentLanguage = line.trim().removePrefix("```").trim()
                inCodeBlock = true
            }
        } else {
            if (inCodeBlock) {
                currentCodeLines.add(line)
            } else {
                currentTextLines.add(line)
            }
        }
    }

    if (inCodeBlock && currentCodeLines.isNotEmpty()) {
        blocks.add(Block.Code(currentLanguage, currentCodeLines.joinToString("\n")))
    } else if (currentTextLines.isNotEmpty()) {
        blocks.add(Block.Text(currentTextLines.joinToString("\n")))
    }

    return blocks
}

fun parseFormattedText(text: String, defaultColor: Color): androidx.compose.ui.text.AnnotatedString {
    return buildAnnotatedString {
        val boldRegex = Regex("\\*\\*(.*?)\\*\\*")
        var lastIdx = 0
        val matches = boldRegex.findAll(text)

        for (match in matches) {
            val start = match.range.first
            val end = match.range.last + 1
            if (start > lastIdx) {
                append(text.substring(lastIdx, start))
            }
            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = defaultColor)) {
                append(match.groupValues[1])
            }
            lastIdx = end
        }
        if (lastIdx < text.length) {
            append(text.substring(lastIdx))
        }
    }
}

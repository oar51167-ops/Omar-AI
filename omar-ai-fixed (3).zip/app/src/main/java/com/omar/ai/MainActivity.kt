package com.omar.ai

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.omar.ai.ui.OmarViewModel
import com.omar.ai.ui.screens.ChatScreen
import com.omar.ai.ui.screens.OnboardingScreen
import com.omar.ai.ui.theme.OmarAITheme
import android.util.Log
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory

class MainActivity : ComponentActivity() {

    private val viewModel: OmarViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // App Check: debug provider for development, Play Integrity for release
        try {
            val appCheck = FirebaseAppCheck.getInstance()
            // Always install debug factory in this build so development APKs work
            // when Firebase AI Logic enforces App Check. For production, switch to Play Integrity.
            appCheck.installAppCheckProviderFactory(
                DebugAppCheckProviderFactory.getInstance()
            )
            Log.i("OmarAI", "App Check Debug provider installed")
        } catch (e: Exception) {
            Log.w("OmarAI", "App Check init skipped", e)
        }
        enableEdgeToEdge()

        // Handle Digital Assistant trigger
        if (Intent.ACTION_ASSIST == intent?.action) {
            viewModel.startNewConversation(isTemporary = true)
        }

        setContent {
            val isArabic by viewModel.isArabic.collectAsState()
            val themeMode by viewModel.themeMode.collectAsState()
            val currentUser by viewModel.currentUser.collectAsState()

            val isDark = when (themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            OmarAITheme(darkTheme = isDark) {
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                ) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        if (currentUser == null || !currentUser!!.isOnboarded) {
                            OnboardingScreen(viewModel = viewModel)
                        } else {
                            ChatScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
